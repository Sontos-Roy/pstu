<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area shadow dark text-center text-light" style="background-image: url('<?php echo e(getImage('settings', getSetting('pagebanner1'))); ?>'); background-size: cover; background-repeat: no-repeat;padding: 103px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <h2><?php echo e($office->name); ?></h2>
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('front.home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                    <li class="active"><?php echo e($office->name); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="course-details-area default-padding">
    <div class="container">
        <div class="row">
            <!-- Start Course Info -->
            <div class="col-md-12">
                <div class="courses-info" style="border-right: none;">
                    <!-- Star Tab Info -->
                    <div class="tab-info">
                        <!-- Tab Nav -->
                        <ul class="nav nav-pills">
                            <li class="active">
                                <a data-toggle="tab" href="#tab1" aria-expanded="true">
                                About
                                </a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#tab2" aria-expanded="false">
                                People
                                </a>
                            </li>
                            <li>
                                <a data-toggle="tab" href="#tab3" aria-expanded="false">
                                Contact
                                </a>
                            </li>
                        </ul>
                        <!-- End Tab Nav -->
                        <!-- Start Tab Content -->
                        <div class="tab-content tab-content-info">
                            <!-- Single Tab -->
                            <div id="tab1" class="tab-pane fade active in">
                                <div class="info title">
                                    <div class="top-author">
                                        <div class="author-items" style="border-top: 3px solid #1C4370;box-shadow:0 0 10px rgba(50, 50, 50, .17);">
                                            <div class="col-lg-10 col-sm-9">
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="col-sm-12 text-justify margin-top-30px">
                                                <?php echo $office->details; ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Tab -->
                            <!-- Single Tab -->
                            <div id="tab2" class="tab-pane fade">
                                <div class="info title">
                                    <div class="advisor-area bottom-less bg-cover">
                                        <div class="container">
                                            <div class="row">
                                                <div class="advisor-items col-3 text-light text-center">
                                                    <!-- Single item -->
                                                    <?php $__currentLoopData = $office->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-6 single-item">
                                                        <div class="item">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="thumb">
                                                                        <img src="<?php echo e(getImage('teachers', $user->userDetails->image)); ?>" alt="Thumb" style="min-height: 200px">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6" style="text-align: center; margin-top: 12%;">
                                                                    <p style="color: black; font-style: italic; font-weight: bold">
                                                                        <?php echo e($user->name); ?>

                                                                    </p>
                                                                    <p style="color: black"><?php echo e($user->userDetails->position); ?></p>
                                                                    <p style="color: black">
                                                                        <i class="fas fa-phone"></i>   <?php echo e($user->userDetails->phone); ?>

                                                                    </p>
                                                                    <p style="color: black"><i class="fas fa-envelope-square"></i> <?php echo e($user->email); ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    <!-- End Single item -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Tab -->
                            <!-- Single Tab -->
                            <div id="tab3" class="tab-pane fade">
                                <div class="info title">
                                    <div class="top-author">
                                        <div class="author-items" style="border-top: 3px solid #1C4370;box-shadow:0 0 10px rgba(50, 50, 50, .17);">
                                            <div class="field-item even">
                                                <?php echo $office->contact; ?>


                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Tab -->
                        </div>
                        <!-- End Tab Content -->
                    </div>
                    <!-- End Tab Info -->
                </div>
            </div>
            <!-- End Course Info -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/frontend/offices/office_show.blade.php ENDPATH**/ ?>