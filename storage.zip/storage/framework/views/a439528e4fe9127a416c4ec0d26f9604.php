<?php $__env->startSection('content'); ?>
    <div class="breadcrumb-area shadow dark text-center text-light" style="background-image: url('<?php echo e(getImage('settings', getSetting('pagebanner1'))); ?>'); background-repeat: no-repeat; padding: 103px 0;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h2><?php echo e($data->title); ?></h2>
                    <ul class="breadcrumb">
                        <li><a href="<?php echo e(route('front.home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                        <li class="active"><?php echo e($data->title); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="course-details-area default-padding">
        <div class="container">
            <div class="row">
                <!-- Start Course Info -->
                <div class="col-md-9">
                    <div class="courses-info">
                        <!-- Star Tab Info -->
                        <div class="tab-info">
                            <!-- Start Tab Content -->
                            <div class="tab-content tab-content-info">
                                <!-- Single Tab -->
                                <div id="tab1" class="tab-pane fade active in">
                                    <div class="info title">
                                        <div class="col-sm-12">
                                            <?php echo $data->details; ?>


                                            <?php echo $data->contact; ?>

                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Tab -->
                            </div>
                            <!-- End Tab Content -->
                        </div>
                        <!-- End Tab Info -->
                    </div>
                </div>
                <!-- End Course Info -->
                <!-- Start Course Sidebar -->
                <div class="col-md-3">
                    <div class="aside">
                        <div class="sidebar-item category">
                            <div class="title">
                                <h4>Admission</h4>
                            </div>
                            <ul>
                                <?php $__currentLoopData = getAdmissions()->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('front.get.admissions', $admission->slug)); ?>" target="_blank"><?php echo e($admission->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </div>

                    </div>
                </div>
                <!-- End Course Sidebar -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
        <script>
    $(document).ready(function(){
        $('#faculties').on('change', function() {
        var facultyId = $(this).val();
        $.ajax({
            url: '<?php echo e(route("admin.get.departments")); ?>',
            type: 'GET',
            dataType: 'json',
            data:{
                id: facultyId
            },
            success: function(data) {
                $(document).find('select#department_id').empty();
                $('select#department_id').html('<option value="">Select One</option>');
                $.each(data, function(index, department) {
                    $('select#department_id').append('<option value ="'+department.id+'">'+department.name+'</option>');
                });
            }
        });
    })
        $('#department_id').on('change', function() {
        var facultyId = $(this).val();
        $.ajax({
            url: '<?php echo e(route("front.get.calendars")); ?>',
            type: 'GET',
            dataType: 'json',
            data:{
                id: facultyId
            },
            success: function(data) {
                $(document).find('#show_result').empty();

                $('#show_result').html(data.html)
            }
        });
    })
})
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/frontend/admissions.blade.php ENDPATH**/ ?>