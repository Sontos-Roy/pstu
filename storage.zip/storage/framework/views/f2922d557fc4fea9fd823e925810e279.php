<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <h2>Edit Staff</h2>
        <small class="text-muted">Patuakhali Science &amp; Technology University</small>
    </div>
    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data" id="ajax_form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>Basic Information</h2>
                    </div>
                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-md-4 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" name="name" class="form-control" placeholder="First Name" value="<?php echo e($user->name); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="date" name="date_of_birth" class="datepicker form-control" placeholder="Date of Birth" data-dtp="dtp_sCohL" value="<?php echo e($user->userDetails? $user->userDetails->date_of_birth :''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <div class="form-group drop-custum">
                                    <select class="form-control show-tick" name="gender">
                                        <option value="">-- Gender --</option>
                                        <option value="Male" <?php echo e($user->userDetails && $user->userDetails->gender == 'Male' ? 'selected': ''); ?>>Male</option>
                                        <option value="Female" <?php echo e($user->userDetails && $user->userDetails->gender == 'Female' ? 'selected': ''); ?>>Female</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <div class="form-group drop-custum">
                                    <select class="form-control show-tick p-2" name="faculty_id">
                                        <option value="">-- Faculty Select --</option>
                                        <?php
                                            if ($user->userDetails && $user->userDetails->faculty_id) {
                                                $faculty_id = $user->userDetails->faculty_id;
                                            }else{
                                                $faculty_id = 0;
                                            }
                                        ?>
                                        <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $faculty_id ? 'selected': ''); ?> class="p-2"><?php echo e($item->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <div class="form-group drop-custum">
                                    <select class="form-control show-tick p-2" name="department_id">
                                        <option value="">-- Department Select --</option>
                                        <?php
                                            if ($user->userDetails && $user->userDetails->department_id) {
                                                $department_id = $user->userDetails->department_id;
                                            }else{
                                                $department_id = 0;
                                            }
                                        ?>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $department_id ? 'selected': ''); ?> class="p-2"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                    <label for="">Select Role</label>
                                    <select class="form-control show-tick p-2 select2 border-none" multiple name="roles[]">
                                        <option value="">-- Role Select --</option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item); ?>" <?php echo e(in_array($item, $userRole) ? 'selected': ''); ?> class="p-2"><?php echo e($item); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="position" placeholder="Position" value="<?php echo e($user->userDetails ? $user->userDetails->position : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <?php if($user->userDetails && $user->userDetails->image): ?>
                                <img src="<?php echo e(getImage('teachers', $user->userDetails ? $user->userDetails->image: '')); ?>" height="100">
                                <br>
                                <?php endif; ?>
                                <label for="">Teacher Image</label>
                                <input type="file" class="form-control" name="image">
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <?php if($user->userDetails && $user->userDetails->banner): ?>
                                <img src="<?php echo e(getImage('teachers', $user->userDetails ? $user->userDetails->banner: '')); ?>" height="100">
                                <br>
                                <?php endif; ?>
                                <label for="">Banner Image</label>
                                <input type="file" class="form-control" name="banner">
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <textarea rows="4" name="present_address" class="form-control no-resize" placeholder="Present Address"><?php echo e($user->userDetails ? $user->userDetails->present_address : ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <textarea rows="4" name="permanent_address" class="form-control no-resize" placeholder="permanent Address"><?php echo e($user->userDetails ? $user->userDetails->permanent_address : ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h2>Professor's Account Information</h2>
                    </div>
                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-md-4 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="phone" placeholder="Phone" value="<?php echo e($user->userDetails ? $user->userDetails->phone : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-4 col-md-4 ">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="email" placeholder="Email" value="<?php echo e($user->email); ?>">
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h2>Professor Social Media Info </h2>

                    </div>
                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="website" placeholder="Website" value="<?php echo e($user->userDetails ? $user->userDetails->website : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="facebook" placeholder="Facebook" value="<?php echo e($user->userDetails ? $user->userDetails->facebook : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="twitter" placeholder="Twitter" value="<?php echo e($user->userDetails ? $user->userDetails->twitter : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="google_plus" placeholder="Google Plus" value="<?php echo e($user->userDetails ? $user->userDetails->google_plus : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="linkedin" placeholder="LinkedIN " value="<?php echo e($user->userDetails ? $user->userDetails->linkedin : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="youtube" placeholder="Youtube" value="<?php echo e($user->userDetails ? $user->userDetails->youtube : ''); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-raised g-bg-blush2">Submit</button>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/backend/teachers/edit.blade.php ENDPATH**/ ?>