﻿

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="d-sm-flex justify-content-between">
            <div>
                <h2>All LeaderShips</h2>
                <small class="text-muted">Patuakhali Science & Technology University</small>
            </div>
            <div>
                <a href="<?php echo e(route('admin.leadership.create')); ?>" class="btn btn-raised btn-defualt">Add LeaderShip</a>
            </div>
        </div>
    </div>
    <!-- Basic Examples -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="body table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>no</th>
                                <th>Name</th>
                                <th>Image</th>
                                <th>Designation</th>
                                <th>slug</th>
                                <th>Message</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $leaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <?php if($item->user): ?>
                                <td><img src="<?php echo e(getImage('teachers', $item->user ? $item->user->userDetails->image : '')); ?>" width="100" alt=""></td>
                                <?php else: ?>
                                <td><img src="<?php echo e(getImage('leaders', $item->image)); ?>" width="100" alt=""></td>
                                <?php endif; ?>
                                <td><?php echo e($item->designation); ?></td>
                                <td><?php echo e($item->slug); ?></td>
                                <td><?php echo e(StrLimit($item->message_short, 200)); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('admin.leadership.show', $item->id)); ?>" class="btn btn-info waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            visibility
                                            </span></a>
                                        <a href="<?php echo e(route('admin.leadership.edit', $item->id)); ?>" class="btn btn-info waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            edit_note
                                            </span></a>
                                    <form action="<?php echo e(route('admin.leadership.destroy', $item->id)); ?>" class="delete_form" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            delete
                                            </span></button>
                                    </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- #END# Basic Examples -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/backend/leadership/index.blade.php ENDPATH**/ ?>