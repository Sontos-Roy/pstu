<?php $__env->startSection('content'); ?>
    <div class="breadcrumb-area shadow dark text-center text-light" style="background-image: url('<?php echo e(getImage('settings', getSetting('pagebanner1'))); ?>'); background-repeat: no-repeat; padding: 103px 0;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h2><?php echo e($item->title); ?></h2>
                    <ul class="breadcrumb">
                        <li><a href="<?php echo e(route('front.home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                        <li class="active"><?php echo e($item->title); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="course-details-area default-padding">
        <div class="container">
            <div class="row">
                <!-- Start Course Info -->
                <div class="col-md-8">
                    <div class="courses-info">
                        <div class="tags pull-right">

                        </div>
                        <div class="clearfix"></div>
                        <h3 class="">
                            <?php echo e($item->title); ?>

                        </h3>
                        <div class="clearfix"></div>
                        <div class="tab-info">
                            <div class="tab-content tab-content-info">
                                <div id="tab1" class="tab-pane fade active in">
                                    <div class="info title text-justify colored-link">
                                        <?php if($item->image): ?>
                                        <img src="<?php echo e(getImage('students', $item->image)); ?>" alt="<?php echo e($item->title); ?>" class="w-100">
                                        <?php endif; ?>
                                        <?php if($item->details): ?>
                                        <?php echo $item->details; ?>

                                        <?php endif; ?>
                                        <?php if($item->pdf): ?>
                                        <a href="<?php echo e(getPdf('students', $item->file)); ?>">মূল বিজ্ঞপ্তিটি দেখতে ক্লিক করুন...</a></p>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>





    <!-- Start Footer


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/frontend/studentpage.blade.php ENDPATH**/ ?>