<?php $__env->startPush('"[request()->segment(1)]"'); ?>
<?php echo e($item->name); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area shadow dark text-center text-light" style="background-image: url('<?php echo e(getImage('settings', getSetting('pagebanner1'))); ?>'); background-size: cover; background-repeat: no-repeat;padding: 103px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <h2>Mission And Vision</h2>
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('front.home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                    <li class="active">Mission And Vision</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="course-details-area default-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="top-author">
                    <div class="author-items" style="border-top: 3px solid #1C4370;box-shadow:0 0 10px rgba(50, 50, 50, .17);">

                        <div class="col-sm-12 text-justify margin-top-30px">
                            <?php echo $data?$data->details:''; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/frontend/mission.blade.php ENDPATH**/ ?>