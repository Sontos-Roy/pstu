<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <h2>Setting</h2>
        <small class="text-muted">Patuakhali Science &amp; Technology University</small>
    </div>
    <form action="<?php echo e(route('admin.settings.update', $setting->id)); ?>" method="POST" id="ajax_form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row clearfix">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">

                    </div>
                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="name" placeholder="Name" value="<?php echo e($setting->name); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="key" placeholder="Key" value="<?php echo e($setting->key); ?>">
                                        <input type="hidden" class="form-control" name="type" placeholder="Type" value="<?php echo e($setting->type); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="form-group">
                                    <div class="form-line">
                                        <?php if($setting->type === 'text'): ?>
                                            <input type="text" name="value" value="<?php echo e($setting->value); ?>" class="form-control" placeholder="Add Value">
                                        <?php elseif($setting->type === 'textarea'): ?>
                                            <textarea name="value" class="form-control" placeholder="Add Value"><?php echo e($setting->value); ?></textarea>
                                        <?php elseif($setting->type === 'image'): ?>
                                            <div class="imageSelect">
                                                Select Image
                                                <input type="file" name="value" class="form-control" id="image-input">
                                                <img id="image-preview" src="#" alt="" width="100">
                                            </div>
                                            <?php if($setting->value): ?>
                                                <img src="<?php echo e(getImage('setting', $setting->value)); ?>" alt="<?php echo e($setting->key); ?>" class="preview-image">
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-raised g-bg-blush2">Save</button>
                </div>
            </div>
        </div>
    </form>
</div>
<style>
    .imageSelect{
        padding: 20px;
    }
</style>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstu\resources\views/backend/settings/edit.blade.php ENDPATH**/ ?>