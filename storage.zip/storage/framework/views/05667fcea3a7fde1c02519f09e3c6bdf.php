<div class="col-md-3">
    <div class="aside">
        <div class="sidebar-item category">
            <div class="title">
                <h4>About University</h4>
            </div>
            <ul>
                <li><a href="<?php echo e(route('front.historic.outline')); ?>">Historical Outline</a></li>
                <li><a href="<?php echo e(route('front.university.glance')); ?>">University at a Glance</a></li>
                <li><a href="<?php echo e(route('front.honoris.causa')); ?>">Honoris Causa</a></li>
                <li><a href="<?php echo e(route('front.vice.chencellors.message', 'vice-chancellor')); ?>">Message from the Vice Chancellor</a></li>
                <li><a href="<?php echo e(route('front.vice.chencellors')); ?>">List of Vice Chancellors</a></li>
            </ul>
        </div>
        <div class="sidebar-item category">
            <div class="title">
                <h4>PSTU Leadership</h4>
            </div>
            <ul>
                <?php $__currentLoopData = LeaderShips(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('front.vice.chencellors.message', $item->slug)); ?>"><?php echo e($item->designation); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="sidebar-item category">
            <div class="title">
                <h4>Governance Framework</h4>
            </div>
            <ul>
                <li><a href="<?php echo e(route('front.university.ordinances')); ?>">University Ordinance</a></li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH G:\xampp\htdocs\pstu\resources\views/frontend/About/sidebar.blade.php ENDPATH**/ ?>