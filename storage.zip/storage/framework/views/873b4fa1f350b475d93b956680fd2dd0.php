<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="d-sm-flex justify-content-between">
            <div>
                <h2>Dashboard</h2>
                <small class="text-muted">Welcome to Patuakhali Science & Technology University</small>
            </div>

        </div>
    </div>


    <div class="row clearfix row-deck">
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="card">
                <div class="body thumbnail">
                    <div class="caption">
                        <h3><?php echo e($role->name); ?></h3>
                        <p><?php echo e($role->users_count); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="clearfix"></div>

        <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="card">
                <div class="body thumbnail">
                    <div class="caption">
                        <h3> Exams (Current Month)</h3>
                        <p><?php echo e($total_exams); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="card">
                <div class="body thumbnail">
                    <div class="caption">
                        <h3> Events (Current Week)</h3>
                        <p><?php echo e($total_events); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row clearfix row-deck">
        <div class="col-sm-6">
            <div class="card">
                <div class="card-header">
                    Upcoming Birthdays
                </div>
                <div class="card-body">
                    <table class="table table-striped table-hovered">
                        <tr>
                            <th>NAME</th>
                            <th>ROLE</th>
                            <th>Date</th>
                        </tr>
                        <?php $__currentLoopData = $upcomins_birthdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->user?$item->user->name:''); ?></td>
                            <td><span class="badge badge-success"><?php echo e($item->user->roles->pluck('name')[0]??''); ?></span></td>
                            <td><?php echo e($item->date_of_birth); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>


        <div class="col-sm-6">
            <div class="card">
                <div class="card-header">
                    Upcoming Events
                </div>
                <div class="card-body">
                    <table class="table table-striped table-hovered">
                        <tr>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                        <?php $__currentLoopData = $upcomins_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->heading); ?></td>
                            <td><span class="badge badge-info">UPcoming</span></td>
                            <td><?php echo e($item->date); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>