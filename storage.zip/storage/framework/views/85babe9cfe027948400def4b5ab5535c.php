<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="d-sm-flex justify-content-between">
            <div>
                <h2>All Images</h2>
                <small class="text-muted">Patuakhali Science & Technology University</small>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('images.create')): ?>
            <div>
                <a href="javascript:void(0)" class="btn btn-raised btn-defualt" data-toggle="modal" data-target="#createsetting">Add Image</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- Basic Examples -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="body table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>no</th>
                                <th>Image</th>
                                <th>Faculty</th>
                                <th>Department</th>
                                <th>Institue</th>
                                <th>Program</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><img src="<?php echo e(getImage('images', $item->image)); ?>" alt="" width="100"></td>
                                <td><?php echo e($item->faculty? $item->faculty->title: ''); ?></td>
                                <td><?php echo e($item->department? $item->department->name: ""); ?></td>
                                <td><?php echo e($item->institute ? $item->institute->name : ''); ?></td>
                                <td><?php echo e($item->program ? $item->program->title : ''); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <!--<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('images.edit')): ?>-->
                                        <!--<a href="<?php echo e(route('admin.images.edit', $item->id)); ?>" class="btn modal_btn btn-info waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">-->
                                        <!--    edit_note-->
                                        <!--    </span></a>-->
                                        <!--<?php endif; ?>-->
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('images.delete')): ?>
                                        <form action="<?php echo e(route('admin.images.destroy', $item->id)); ?>" class="delete_form" method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                                delete
                                                </span></button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- #END# Basic Examples -->
</div>
<!-- Button to Open the Modal -->

  <!-- The Modal -->
  <div class="modal fade" id="createsetting" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="createsettingLabel">Outline Add</h4>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('admin.images.store')); ?>" method="POST" id="ajax_form">
                    <?php echo csrf_field(); ?>
                    <div class="container">
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Faculty</label>
                                <div class="col-8">
                                    <select name="faculty_id" id="" class="form-control">
                                        <option value="">Select One</option>
                                        <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($faculty->id); ?>"><?php echo e($faculty->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Department</label>
                                <div class="col-8">
                                    <select name="department_id" id="" class="form-control">
                                        <option value="">Select One</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Institute</label>
                                <div class="col-8">
                                    <select name="institute_id" id="" class="form-control">
                                        <option value="">Select One</option>
                                        <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($institute->id); ?>"><?php echo e($institute->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Programs</label>
                                <div class="col-8">
                                    <select name="program_id" id="" class="form-control">
                                        <option value="">Select One</option>
                                        <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($program->id); ?>"><?php echo e($program->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Details</label>
                                <div class="col-8">
                                    <input type="file" multiple class="form-control" style="border: 1px solid black;" name="images[]">
                                </div>
                            </div>


                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
                <button type="submit" form="ajax_form" class="btn btn-link waves-effect">SAVE CHANGES</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
     $(document).ready(function() {

    });
</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make("backend.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/backend/Images/index.blade.php ENDPATH**/ ?>