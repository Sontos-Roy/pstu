<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <h2>View Research Center</h2>
        <small class="text-muted">Patuakhali Science & Technology University</small>
    </div>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-12 p-2">
                                <strong>Research Center Name: </strong>
                                <p><?php echo e($item->name); ?></p>
                            </div>
                            <div class="col-12 p-2">
                                <strong>Research Center Slug: </strong>
                                <p><?php echo e($item->slug); ?></p>
                            </div>
                            <div class="col-12 p-2">
                                <strong>Research Center Director: </strong>
                                <p><?php echo e($item->user->name); ?></p>
                            </div>
                            <div class="col-12 p-2">
                                <strong>Research Center Short Info: </strong>
                                <p><?php echo e($item->short); ?></p>
                            </div>
                            <div class="col-12 p-2">
                                <strong>Research Center Full Details: </strong>
                                <p><?php echo $item->brief; ?></p>
                            </div>
                        </div>

                    </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/backend/research_center/view.blade.php ENDPATH**/ ?>