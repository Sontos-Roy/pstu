<?php $__env->startSection('content'); ?>
<style>
    .profile-page .profile-header .profile_info .profile-image img{
        aspect-ratio: 3/3;
        height: 250px;
    }
</style>
<div class="container-fluid emp-profile">
            <form method="post">
                <div class="row">
                    <div class="col-md-6">
                        <div class="profile-img">
                            <img src="<?php echo e(getImage('teachers', $teacher->userDetails ? $teacher->userDetails->image : '')); ?>" alt="" width="150" />
                         
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="profile-head">
                                    <h5><?php echo e($teacher->name); ?> </h5>
                                    <h6>
                                        <?php $__currentLoopData = $teacher->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-info"><?php echo e($role->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </h6>

                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Timeline</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="profile-work">
                            <div id="accordion">
                                  <div class="card">
                                    <div class="card-header" id="headingOne">
                                      <h5 class="mb-0">
                                        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            Education
                                        </button>
                                      </h5>
                                    </div>

                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                      <div class="card-body">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped table-hover">
                                                    <tr>
                                                        <th>Degree Name</th>
                                                        <th> Group/Major Subject</th>
                                                        <th> Board/Institute </th>
                                                        <th> Country </th>
                                                        <th> Passing Year </th>
                                                        <th> Action </th>
                                                    </tr>

                                                    <?php $__currentLoopData = $teacher->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($edu->degree_name); ?></td>
                                                        <td><?php echo e($edu->mejor_subject); ?></td>
                                                        <td><?php echo e($edu->institute); ?></td>
                                                        <td><?php echo e($edu->country); ?></td>
                                                        <td><?php echo e($edu->passing_year); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>

                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                      <h5 class="mb-0">
                                        <button class="btn btn-link" data-toggle="collapse" data-target="#Experiences" aria-expanded="true" aria-controls="Experiences">
                                            Experiences
                                        </button>
                                      </h5>
                                    </div>

                                    <div id="Experiences" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                      <div class="card-body">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped table-hover">
                                                    <tr>
                                                        <th> Title</th>
                                                        <th> Organization</th>
                                                        <th> Location </th>
                                                        <th> From Date </th>
                                                        <th> TO Date </th>
                                                        <th> Action </th>
                                                    </tr>

                                                    <?php $__currentLoopData = $teacher->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($edu->title); ?></td>
                                                        <td><?php echo e($edu->organization); ?></td>
                                                        <td><?php echo e($edu->location); ?></td>
                                                        <td><?php echo e($edu->from_date); ?></td>
                                                        <td><?php echo e($edu->to_date); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>

                                  <div class="card">
                                    <div class="card-header" id="headingOne">
                                      <h5 class="mb-0">
                                        <button class="btn btn-link" data-toggle="collapse" data-target="#Memberships" aria-expanded="true" aria-controls="Memberships">
                                            Memberships
                                        </button>
                                      </h5>
                                    </div>

                                    <div id="Memberships" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                      <div class="card-body">
                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped table-hover">
                                                    <tr>
                                                        <th> Name</th>
                                                        <th> Type</th>
                                                        <th> Membership Year </th>
                                                        <th> Expire Year </th>
                                                        <th> Action </th>
                                                    </tr>

                                                    <?php $__currentLoopData = $teacher->memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($edu->name); ?></td>
                                                        <td><?php echo e($edu->type); ?></td>
                                                        <td><?php echo e($edu->membership_year); ?></td>
                                                        <td><?php echo e($edu->expire_year); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>


                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                  
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Name</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p> <?php echo e($teacher->name); ?></p>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Department</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p> <?php echo e($teacher->userDetails && $teacher->userDetails->department ? $teacher->userDetails->department->name : ''); ?></p>
                                            </div>
                                        </div>

                                        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Email</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($teacher->email); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Phone</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($teacher->userDetails ? $teacher->userDetails->phone : ''); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Position</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($teacher->userDetails ? $teacher->userDetails->position : ''); ?></p>
                                            </div>
                                        </div>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Present_ Address</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($teacher->userDetails ? $teacher->userDetails->present_address : ''); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Permanent Address</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($teacher->userDetails ? $teacher->userDetails->permanent_address : ''); ?></p>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label> Website</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($teacher->userDetails ? $teacher->userDetails->website : ''); ?></p>
                                            </div>
                                        </div>

                                        

                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <label> Social Media</label><br/>
                                                <ul class="social-links  m-t-10">
                                                    <li><a title="facebook" href="<?php echo e($teacher->userDetails ? $teacher->userDetails->facebook : ''); ?>"><i class="zmdi zmdi-facebook"></i></a></li>
                                                    <li><a title="twitter" href="<?php echo e($teacher->userDetails ? $teacher->userDetails->twitter : ''); ?>"><i class="zmdi zmdi-twitter"></i></a></li>
                                                    <li><a title="instagram" href="<?php echo e($teacher->userDetails ? $teacher->userDetails->youtube : ''); ?>"><i class="zmdi zmdi-youtube"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>           
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/backend/teachers/view.blade.php ENDPATH**/ ?>