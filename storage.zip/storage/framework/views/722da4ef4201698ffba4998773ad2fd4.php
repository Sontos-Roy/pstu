<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="PSTU">

    <title>PSTU</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="assets1/img/pstulogo.png') }}" type="image/x-icon"/>

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/flaticon-set.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/themify-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/magnific-popup.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/animate.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/bootsnav.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->


    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800" rel="stylesheet">
    <?php echo $__env->yieldPushContent('css'); ?>

</head>
<body>
    <div class="top-bar-area bg-dark inc-border text-light">
        <div class="container">
            <div class="row">

                <div class="col-md-8 address-info text-left">
                    <div class="info">
                        <ul>
                            <li class="social">
                                <a href="<?php echo e(getSetting('facebook')); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <a href="<?php echo e(getSetting('twitter')); ?>" target="_blank"><i class="fab fa-twitter"></i></a>
                                <a href="<?php echo e(getSetting('linkedin')); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                                <a href="<?php echo e(getSetting('youtube')); ?>" target="_blank"><i class="fab fa-youtube"></i></a>
                            </li>
                            <li>
                                <i class="fas fa-user-shield"></i> Instructor: <strong><?php echo e(getTeachers()->count()); ?></strong>
                            </li>
                            <li>
                                <i class="fas fa-phone"></i> Help Line: <strong><?php echo e(getSetting('phone')); ?></strong>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-4 link text-right">
                    <ul>
                        <!-- <li>
                            <a href="#">Register</a>
                        </li> -->
                        <li>
                            <a href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Header
    ============================================= -->
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar top-pad navbar-default attr-border-none navbar-fixed navbar-transparent white bootsnav">

            <!-- Start Top Search -->
            <div class="container">
                <div class="row">
                    <div class="top-search">
                        <div class="input-group">
                            <form action="#">
                                <input type="text" name="text" class="form-control" placeholder="Search">
                                <button type="submit">
                                    <i class="ti-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Top Search -->

            <div class="container">

                <!-- Start Atribute Navigation -->
                
                <!-- End Atribute Navigation -->

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(route('front.home')); ?>">
                        <div class="p-1" style="
                        margin-top: 4px;
                        position: absolute;
                        background: white;
                        border-radius: 0 0 45% 45%; padding: 0 4px 2px;">
                            <img src="<?php echo e(getImage('settings', getSetting('logo'))); ?>" class="logo logo-display" alt="Logo" style="
                        width: 80px;" >
                        </div>
                        <!-- <center><span style="color:lightcoral">PSTU</span></center> -->
                        <img src="<?php echo e(getImage('settings', getSetting('logo'))); ?>" class="logo logo-scrolled" alt="Logo" style="width:84px;">
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="">
                            <a href="<?php echo e(route('front.home')); ?>" class="">
                                Home
                            </a>
                        </li>
                        <li class="dropdown megamenu-fw">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">About
                            <span></span>
                            </a>
                            <ul class="dropdown-menu megamenu-content animated menuBody fadeOutUp" role="menu" style="display: none; opacity: 1;">
                                <li>
                                    <div>
                                    <div class="col-menu col-md-4">
                                        <h6 class="title menuTitle">About University
                                        </h6>
                                        <div class="content">
                                            <ul class="menu-col">
                                                <li>
                                                <a href="<?php echo e(route('front.historic.outline')); ?>">
                                                <i class="fas fa-angle-double-right"></i> Historical Outlines
                                                </a>
                                                </li>
                                                <li>
                                                <a href="<?php echo e(route('front.honoris.causa')); ?>">
                                                <i class="fas fa-angle-double-right"></i> Honoris Causas
                                                </a>
                                                </li>
                                                <li>
                                                <a href="<?php echo e(route('front.university.glance')); ?>">
                                                <i class="fas fa-angle-double-right"></i>
                                                University at a
                                                Glance
                                                </a>
                                                </li>
                                                <li>
                                                <a href="<?php echo e(route('front.vice.chencellors.message', 'vice-chancellor')); ?>">
                                                <i class="fas fa-angle-double-right"></i>
                                                Message from the Vice
                                                Chancellor
                                                </a>
                                                </li>
                                                <li>
                                                <a href="<?php echo e(route('front.vice.chencellors')); ?>">
                                                <i class="fas fa-angle-double-right"></i>
                                                Vice Chencellors List
                                                </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- end col-3 -->
                                    <div class="col-menu col-md-4">
                                        <h6 class="title menuTitle">University Leadership</h6>
                                        <div class="content">
                                            <ul class="menu-col">
                                                <?php $__currentLoopData = LeaderShips(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e(route('front.vice.chencellors.message', $item->slug)); ?>"><i class="fas fa-angle-double-right"></i>
                                                    <?php echo e($item->designation); ?></a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </ul>
                                        </div>
                                    </div>
                                    <!-- end col-3 -->
                                    <div class="col-menu col-md-4">
                                        <h6 class="title menuTitle">Governance Framework</h6>
                                        <div class="content">
                                            <ul class="menu-col">
                                                <li><a href="<?php echo e(route('front.university.ordinances')); ?>"><i class="fas fa-angle-double-right"></i>
                                                University
                                                Ordinance</a>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                    <!-- end col-3 -->
                                    </div>
                                    <!-- end row -->
                                </li>
                            </ul>
                        </li>
                        <li class="">
                            <a href="<?php echo e(route('front.notices')); ?>" class="">
                                Notices
                            </a>
                        </li>
                        <li class="">
                            <a href="<?php echo e(route('front.news')); ?>" class="">
                                News
                            </a>
                        </li>

                        <li class="dropdown megamenu-fw">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Faculties <span></span></a>
                            <ul class="dropdown-menu megamenu-content animated menuBody" role="menu" style="display: none; opacity: 1;">
                                <li>
                                    <div>
                                        <div class="col-menu col-md-6">
                                            <h6 class="title menuTitle">Faculties Heads</h6>
                                            <div class="content">
                                                <ul class="menu-col">

                                                    <?php $__currentLoopData = getFaculties(0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('front.faculties.show', $item->slug)); ?>">
                                                        <i class="fas fa-angle-double-right"></i> <?php echo e($item->title); ?>

                                                        </a>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </ul>
                                            </div>
                                        </div>
                                        <!-- end col-3 -->
                                        <div class="col-menu col-md-6">
                                            <h6 class="title menuTitle">Faculties Heads</h6>
                                            <div class="content">
                                                <ul class="menu-col">
                                                    <?php $__currentLoopData = getFaculties(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('front.faculties.show', $item->slug)); ?>">
                                                        <i class="fas fa-angle-double-right"></i> <?php echo e($item->title); ?>

                                                        </a>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- end row -->
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown megamenu-fw">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Administration <span></span></a>
                            <ul class="dropdown-menu megamenu-content animated menuBody" role="menu">
                                <li>
                                    <div class="row">
                                    <div class="col-menu col-md-12">
                                        <h6 class="title menuTitle">Academic Heads</h6>
                                        <div class="content">
                                            <ul class="menu-col">
                                                <li><a href="<?php echo e(route('front.get.deans')); ?>"><i class="fas fa-angle-double-right"></i> Deans of
                                                Faculties</a>
                                                </li>
                                                <li><a href="<?php echo e(route('front.get.heads')); ?>"><i class="fas fa-angle-double-right"></i> Chairman of
                                                Departments</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!-- end col-3 -->

                                    <!-- end col-3 -->
                                    </div>
                                    <!-- end row -->
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Students
                            <span></span></a>
                            <ul class="dropdown-menu animated menuBody" role="menu">
                                <li>
                                    <div class="row">
                                        <div class="content">
                                            <ul class="menu-col">

                                                <?php $__currentLoopData = getStudentPage(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e(route('front.student.page', $item->slug)); ?>" target="_blank"><i class="fas fa-angle-double-right"></i>
                                                    <?php echo e($item->title); ?>

                                                    </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </ul>
                                        </div>

                                    </div>
                                </li>
                            </ul>
                        </li>


                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
        </nav>        <!-- End Navigation -->

    </header>
    <!-- End Header -->

    <?php echo $__env->yieldContent('content'); ?>


     <!-- Start Footer
    ============================================= -->
    <footer class="bg-dark text-light">
        <div class="container logo">
            <div class="f-items footer-default-padding">
                <div class="row ">
                    <div class="row" style="margin-top:50px"></div>
                    <!-- Single item -->
                    <div class="col-md-4 col-sm-6 item equal-height" style="height: 222px;">
                        <div class="f-item link aos-init aos-animate" data-aos="" data-aos-duration="3000" style="line-height:18px">
                            <h4>PSTU</h4>
                            <ul>
                                <li><a href="<?php echo e(route('front.page.show', 'welcome-message')); ?>"><i class="ti-angle-right"></i> Overview</a></li>
                                <li> <a href="<?php echo e(route('front.historic.outline')); ?>"><i class="ti-angle-right"></i> Historic Outline</a> </li>
                                    <li> <a href="<?php echo e(route('front.university.glance')); ?>"><i class="ti-angle-right"></i> At A Glance</a> </li>
                                    <li> <a href="<?php echo e(route('front.honoris.causa')); ?>"><i class="ti-angle-right"></i> Honoris Causa</a> </li>


                            </ul>
                        </div>
                    </div>
                    <!-- End Single item -->


                    <!-- End Single item -->

                    <div class="col-md-4 col-sm-6 item equal-height" style="height: 222px;">
                        <div class="f-item link aos-init aos-animate" data-aos="" data-aos-duration="3000" style="line-height:18px">
                            <h4>&nbsp; LeaderShips</h4>
                            <ul>
                                <?php $__currentLoopData = LeaderShips(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('front.vice.chencellors.message', $item->slug)); ?>" target="_blank">
                                            <i class="ti-angle-right"></i> <?php echo e($item->user->name); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <!-- Single item -->
            <!-- End Single item -->

            <!-- Single item -->
            <div class="col-md-4 col-sm-6">
                <div class="col-sm-12">
                    <img src="<?php echo e(getImage('settings', getSetting('logo'))); ?>" style="width:60px; height:60px;" class="logo" alt="Logo">
                    <div class="clearfix"></div>
                    <div class="footer-content urgent-need aos-init aos-animate" data-aos="" data-aos-duration="3000">
                        <p style="font-size:13px;">
                            <i class="fa fa-map-marker"></i>
                            <?php echo e(getSetting('address')); ?><br>

                        </p>
                        <p>
                            <a class="telephone">
                                <b>Phone:</b> <?php echo e(getSetting('phone')); ?></a>
                            <br>
                            <a class="telephone">
                                <b>Fax:</b> <?php echo e(getSetting('fax')); ?></a>
                            <br>
                            <a href="mailto:<?php echo e(getSetting('email')); ?>">
                                <b>Email:</b> <?php echo e(getSetting('email')); ?>, <?php echo e(getSetting('alt_email')); ?>

                            </a>
                        </p>
                    </div>

                </div>

            </div>

        </div>
        </div>
        <!-- End Single item -->
        </div>


        <!-- Start Footer Bottom -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <?php echo getSetting('copyright'); ?>

                    </div>
                    <!-- <div class="col-md-4 text-right link">
                        <ul>
                            <li>
                                <a href="#" target="_blank">Admin Login</a>
                            </li>
                            <li>
                                <a href="#">Student Login</a>
                            </li>
                            <li>
                                <a href="#" target="_blank">AIS Dashboard</a>
                            </li>
                        </ul>
                    </div> -->
                </div>
            </div>
        </div>

        <!-- End Footer Bottom -->

    </footer>    <!-- End Footer -->

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="<?php echo e(asset('frontend/js/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/equal-height.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.appear.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/modernizr.custom.13711.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/progress-bar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/count-to.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/YTPlayer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/loopcounter.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/bootsnav.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('script'); ?>

</body>

</html>
<?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/frontend/partials/app.blade.php ENDPATH**/ ?>