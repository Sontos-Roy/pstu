<?php $__env->startSection('content'); ?>
<style>
    .member-card.verified .member-thumb img {
        min-width: 280px;
    }
</style>
<div class="container-fluid">
    <div class="block-header">
        <div class="d-sm-flex justify-content-between">
            <div>
                <h2>All Staff</h2>
                <small class="text-muted">Patuakhali Science &amp; Technology University</small>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.create')): ?>
            <div>
                <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-raised btn-primary">Add Staff</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="body table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Department</th>
                                <th>Position</th>
                                <th>role</th>

                                <th>Address</th>
                                <th>Website</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><img src="<?php echo e(getImage('teachers', $teacher->userDetails ? $teacher->userDetails->image : '')); ?>" width="80" alt=""></td>
                                <td><?php echo e(StrLimit($teacher->name, 100)); ?></td>
                                <td><?php echo e($teacher->userDetails && $teacher->userDetails->department ? $teacher->userDetails->department->name : ''); ?></td>
                                <td><?php echo e($teacher->userDetails ? $teacher->userDetails->position : ''); ?></td>
                                <td>
                                    <?php $__currentLoopData = $teacher->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <span class="badge badge-info"><?php echo e($role->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($teacher->userDetails ? $teacher->userDetails->present_address : ''); ?></td>
                                <td><?php echo e(Str::limit($teacher->userDetails ? $teacher->userDetails->website : '', 20, '...')); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('admin.users.show', $teacher->id)); ?>" class="btn btn-info waves-effect pull-right btn-xs" style="color: white;">
                                            show
                                        </a>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.edit')): ?>
                                        <a href="<?php echo e(route('admin.users.edit', $teacher->id)); ?>" class="btn btn-primary waves-effect pull-right btn-xs" style="color: white;">edit
                                        </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.delete')): ?>
                                        <form action="<?php echo e(route('admin.users.destroy', $teacher->id)); ?>" class="delete_form" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger waves-effect pull-right btn-xs" style="color: white;">delete</button>
                                        </form>
                                        <?php endif; ?>
                                    </div>

                                    <ul class="social-links  m-t-10 d-none">
                                        <li><a title="facebook" href="<?php echo e($teacher->userDetails ? $teacher->userDetails->facebook : ''); ?>"><i class="zmdi zmdi-facebook"></i></a></li>
                                        <li><a title="twitter" href="<?php echo e($teacher->userDetails ? $teacher->userDetails->twitter : ''); ?>"><i class="zmdi zmdi-twitter"></i></a></li>
                                        <li><a title="instagram" href="<?php echo e($teacher->userDetails ? $teacher->userDetails->youtube : ''); ?>"><i class="zmdi zmdi-youtube"></i></a></li>
                                    </ul>

                                    <div class="dropdown">
                                      <button type="button" class="btn dropdown-toggle" data-toggle="dropdown">
                                        Details
                                      </button>
                                      <div class="dropdown-menu">
                                        <a class="dropdown-item modal_btn" href="<?php echo e(route('admin.user_educations.create')); ?>?user_id=<?php echo e($teacher->id); ?>">Education Add</a>
                                        <a class="dropdown-item modal_btn" href="<?php echo e(route('admin.user_experience.create')); ?>?user_id=<?php echo e($teacher->id); ?>">Experience Add</a>
                                        <a class="dropdown-item modal_btn" href="<?php echo e(route('admin.user_awards.create')); ?>?user_id=<?php echo e($teacher->id); ?>">Award Add</a>
                                        <a class="dropdown-item modal_btn" href="<?php echo e(route('admin.user_memberships.create')); ?>?user_id=<?php echo e($teacher->id); ?>">Membership Add</a>
                                        <a class="dropdown-item modal_btn" href="<?php echo e(route('admin.user_research_interest.create')); ?>?user_id=<?php echo e($teacher->id); ?>">Research Interest Add</a>
                                        <a class="dropdown-item modal_btn" href="<?php echo e(route('admin.user_research_supervision.create')); ?>?user_id=<?php echo e($teacher->id); ?>">Research Supervision Add</a>
                                      </div>
                                    </div>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php echo e($teachers->links('pagination::bootstrap-4')); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/backend/teachers/teachers.blade.php ENDPATH**/ ?>