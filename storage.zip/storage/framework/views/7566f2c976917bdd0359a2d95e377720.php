<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area shadow dark text-center text-light" style="background-image: url('<?php echo e(getImage('settings', getSetting('pagebanner1'))); ?>'); background-repeat: no-repeat; padding: 103px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <h2>Approved NOC / GO</h2>
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('front.home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                    <li class="active">Approved NOC / GO</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="container" style="margin-top:40px">
    <div class="row">
        <!-- Start Course Info -->
        <div class="col-md-12">
            <div style="height: 40px; background-color: #000; padding:2; color: #fff; line-height: 40px">
                Approved NOC / GO
            </div>
            <div class="table-responsive">
                <table class="table table-stripped table-hovered">
                    <tr>
                        <td>Sl</td>
                        <td>Name</td>
                        <td>Designation</td>
                        <td>Department/Office</td>
                        <td>Type</td>
                        <td>Date</td>
                        <td>Attachment</td>
                    </tr>

                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($item->user->name); ?></td>
                        <td><?php echo e($item->user->designation?$item->user->designation->name :''); ?></td>
                        <td><?php echo e($item->user->department?$item->user->department->name :''); ?></td>
                        <td><?php echo e($item->type); ?></td>
                        <td><?php echo e($item->date); ?></td>
                        <td>
                            <a target="_blank" href="<?php echo e(getPdf('noces', $item->pdf_file)); ?>">View</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <hr>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/frontend/noc_list.blade.php ENDPATH**/ ?>