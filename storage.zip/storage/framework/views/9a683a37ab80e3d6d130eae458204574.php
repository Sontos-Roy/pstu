<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="d-sm-flex justify-content-between">
            <div>
                <h2>All Sliders</h2>
                <small class="text-muted">Patuakhali Science & Technology University</small>
            </div>
            <div>
                <a href="javascript:void(0)" class="btn btn-raised btn-defualt" data-toggle="modal" data-target="#createsetting">Add Slider</a>
            </div>
        </div>
    </div>
    <!-- Basic Examples -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="body table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>no</th>
                                <th>Heading</th>
                                <th>For</th>
                                <th>Faculty</th>
                                <th>Department</th>
                                <th>First Button</th>
                                <th>Second Button</th>
                                <th>Is Active</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->head); ?></td>
                                <td><?php echo e($item->select_for); ?></td>
                                <td><?php echo e($item->faculty ? $item->faculty->title: ''); ?></td>
                                <td><?php echo e($item->department ? $item->department->name: ''); ?></td>
                                <td><?php echo e($item->first_btn); ?></td>
                                <td><?php echo e($item->second_btn); ?></td>
                                <td>
                                    <div class="switch">
                                        <label class="d-flex">OFF
                                            <input type="checkbox" <?php echo e($item->isActive == 1 ? 'checked' : ''); ?> data-url="<?php echo e(route('admin.change.slider.status', $item->id)); ?>" class="isActiveCheckbox">
                                            <span class="lever"></span>ON</label>
                                     </div>
                                </td>
                                <td><?php echo e($item->type); ?></td>
                                <td>
                                        <img src="<?php echo e(getImage('sliders', $item->image)); ?>" alt="<?php echo e($item->image); ?>" width="100">
                                </td>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('admin.sliders.edit', $item->id)); ?>" class="btn modal_btn btn-info waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            edit_note
                                            </span></a>
                                    <form action="<?php echo e(route('admin.sliders.destroy', $item->id)); ?>" class="delete_form" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            delete
                                            </span></button>
                                    </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- #END# Basic Examples -->
</div>
<!-- Button to Open the Modal -->

  <!-- The Modal -->
  <div class="modal fade" id="createsetting" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="createsettingLabel">Slider Add</h4>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('admin.sliders.index')); ?>" method="POST" id="ajax_form">
                    <?php echo csrf_field(); ?>
                    <div class="container">
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Head Text</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="head">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">First Button</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="first_btn">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Second Button</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="second_btn">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">First Button Link</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="first_btn_link">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Second Button Link</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="second_btn_link">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Select For</label>
                                <div class="col-8">
                                        <select class="form-control shadow-none" name="select_for" id="select_for">
                                            <option selected>Select one</option>
                                            <option value="main">Main Page</option>
                                            <option value="faculty">Faculty Section</option>
                                            <option value="department">Department Section</option>
                                        </select>
                                </div>
                            </div>
                            <div class="mb-3 row faculty">
                                <label for="" class="col-4 col-form-label">Select Faculty</label>
                                <div class="col-8">
                                        <select class="form-control shadow-none" name="faculty_id" id="">
                                            <option value="">Select one</option>
                                            <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($faculty->id); ?>"><?php echo e($faculty->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                            </div>
                            <div class="mb-3 row department">
                                <label for="" class="col-4 col-form-label">Select Department</label>
                                <div class="col-8">
                                        <select class="form-control shadow-none" name="department_id" id="">
                                            <option value="">Select one</option>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputName" class="col-4 col-form-label">Slider Active Or Not</label>
                                <div class="col-8">
                                    <div class="switch">

                                        <label>OFF
                                            <input type="checkbox" name="isActive">
                                            <span class="lever"></span>ON</label>
                                     </div>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputName" class="col-4 col-form-label">Type</label>
                                <div class="col-8">
                                    <input type="file" class="form-control" style="border: 1px solid black;" name="image">
                                </div>
                            </div>

                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
                <button type="submit" form="ajax_form" class="btn btn-link waves-effect">SAVE CHANGES</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
     $(document).ready(function() {
        $('.faculty').hide();
        $('.department').hide();
        $('#select_for').on('change', function(){

            var value = $(this).val();
            if(value == 'main'){
                $('.faculty').hide();
                $('.faculty').val(null);
                $('.department').hide();
                $('.department').val(null);
            }else if(value == 'faculty'){
                $('.faculty').show();
                $('.department').hide();
                $('.department').val(null);
            }else if(value == 'department'){
                $('.faculty').hide();
                $('.department').show();
                $('.faculty').val(null);
            }
        });
        $('.isActiveCheckbox').on('change', function() {
            var isActive = $(this).is(':checked');
            var url = $(this).attr('data-url');

            $.ajax({
                url: url,
                type: "POST",
                data: {
                    isActive: isActive,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(res) {
                    Toast.fire({
                        icon: 'success',
                        title: res.msg
                    });
                },
                error: function(xhr, status, error) {
                    // Handle error response if needed
                }
            });
        });
    });
</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make("backend.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/backend/homeSlider/index.blade.php ENDPATH**/ ?>