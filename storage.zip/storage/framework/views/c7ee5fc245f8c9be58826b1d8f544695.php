<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area shadow dark text-center text-light" style="background-image: url('<?php echo e(getImage('settings', getSetting('pagebanner1'))); ?>'); background-size: cover; background-repeat: no-repeat;padding: 103px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <h2>Historical Outlines</h2>
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('front.home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                    <li class="active">Historical Outlines</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="course-details-area default-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="courses-info">
                    <div class="tab-info">
                        <div class="tab-content tab-content-info">
                            <div id="tab1" class="tab-pane fade active in">
                                <div class="info title text-justify">
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-body text-justify">
                                        <div class="wrapper center-block">
                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                                <?php $__currentLoopData = $outlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading <?php echo e($key==0?'active':''); ?>" role="tab" id="heading_<?php echo e($item->id); ?>">
                                                        <h4 class="panel-title">
                                                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne_<?php echo e($item->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                                                            Year : <?php echo e($item->year); ?>

                                                            </a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapseOne_<?php echo e($item->id); ?>" class="panel-collapse <?php echo e($key == 0?'in':'collapse'); ?>" role="tabpanel" aria-labelledby="heading_<?php echo e($item->id); ?>">
                                                        <div class="panel-body">
                                                            <?php echo e($item->details); ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('frontend.About.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/frontend/About/historic.blade.php ENDPATH**/ ?>