<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="d-sm-flex justify-content-between">
            <div>
                <h2>All Events</h2>
                <small class="text-muted">Patuakhali Science & Technology University</small>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('events.create')): ?>
            <div>
                <a href="<?php echo e(route('admin.events.create')); ?>" class="btn btn-raised btn-defualt">Add Event</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- Basic Examples -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="body table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>no</th>
                                <th>Heading</th>
                                <th>slug</th>
                                <th>Message</th>
                                <th>Date and Time</th>
                                <th>User</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e(StrLimit($item->heading, 100)); ?></td>
                                <td><?php echo e(StrLimit($item->slug, 100)); ?></td>
                                <td><?php echo e(StrLimit($item->short, 100)); ?></td>
                                <td><?php echo e(date('d M Y', strtotime($item->date))); ?>, <?php echo e(date('h:i A', strtotime($item->time))); ?></td>
                                <td><?php echo e($item->user->name); ?></td>
                                <td><img src="<?php echo e(getImage('events', $item->image)); ?>" width="100" alt=""></td>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('admin.events.show', $item->id)); ?>" class="btn btn-info waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            visibility
                                            </span></a>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('events.edit')): ?>
                                        <a href="<?php echo e(route('admin.events.edit', $item->id)); ?>" class="btn btn-info waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            edit_note
                                            </span>
                                        </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('events.delete')): ?>
                                        <form action="<?php echo e(route('admin.events.destroy', $item->id)); ?>" class="delete_form" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            delete
                                            </span></button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- #END# Basic Examples -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/backend/events/index.blade.php ENDPATH**/ ?>