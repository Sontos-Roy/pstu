﻿

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="d-sm-flex justify-content-between">
            <div>
                <h2>All Academic Calendar</h2>
                <small class="text-muted">Patuakhali Science & Technology University</small>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('academic_calendars.create')): ?>
            <div>
                <a href="<?php echo e(route('admin.academic_calendars.create')); ?>" class="btn btn-raised btn-defualt">Add Calendar</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- Basic Examples -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="body table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>no</th>
                                <th>Name</th>
                                <th>Aca. Year</th>
                                <th>Faculty</th>
                                <th>Department</th>
                                <th>Class Start</th>
                                <th>Class Completion</th>
                                <th>First Mid</th>
                                <th>Second Mid</th>
                                <th>Field Work</th>
                                <th>Final Exam Start</th>
                                <th>Final End</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->academic_year); ?></td>
                                <td><?php echo e($item->faculty_id); ?></td>
                                <td><?php echo e($item->department_id); ?></td>
                                <td><?php echo e($item->class_start); ?></td>
                                <td><?php echo e($item->class_completion); ?></td>
                                <td><?php echo e($item->first_mid_term); ?></td>
                                <td><?php echo e($item->second_mid_term); ?></td>
                                <td><?php echo e($item->field_work); ?></td>
                                <td><?php echo e($item->final_exam_start); ?></td>
                                <td><?php echo e($item->final_exam_end); ?></td>
                                <td>
                                    <div class="d-flex">

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('academic_calendars.edit')): ?>
                                        <a href="<?php echo e(route('admin.academic_calendars.edit', $item->id)); ?>" class="btn btn-info waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            edit_note
                                            </span>
                                        </a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('academic_calendars.delete')): ?>
                                        <form action="<?php echo e(route('admin.academic_calendars.destroy', $item->id)); ?>" class="delete_form" method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                                delete
                                                </span>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- #END# Basic Examples -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("backend.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/backend/academic_calendars/index.blade.php ENDPATH**/ ?>