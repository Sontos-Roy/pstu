<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <div class="d-sm-flex justify-content-between">
            <div>
                <h2>All Pages</h2>
                <small class="text-muted">Patuakhali Science & Technology University</small>
            </div>
            <div>
                <a href="<?php echo e(route('admin.pages.create')); ?>" class="btn btn-raised btn-defualt">Add Page</a>
            </div>
        </div>
    </div>
    <!-- Basic Examples -->
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="body table-responsive">
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <thead>
                            <tr>
                                <th>no</th>
                                <th>Title</th>
                                <th>slug</th>
                                <th>short</th>
                                <th>Is Active</th>
                                <th>Image</th>
                                <th>createdBy</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->slug); ?></td>
                                <td><?php echo e(StrLimit($item->short, 80)); ?></td>
                                <td>
                                    <div class="switch">
                                        <label class="d-flex">OFF
                                            <input type="checkbox" <?php echo e($item->is_active == 1 ? 'checked' : ''); ?> data-url="<?php echo e(route('admin.change.page.status', $item->id)); ?>" class="isActiveCheckbox">
                                            <span class="lever"></span>ON</label>
                                     </div>
                                </td>
                                <td>
                                        <img src="<?php echo e(getImage('pages', $item->image)); ?>" alt="<?php echo e($item->image); ?>" width="100">
                                </td>
                                <td><?php echo e($item->user->name); ?></td>
                                <td>
                                    <div class="d-flex">
                                        <a href="<?php echo e(route('admin.pages.show', $item->id)); ?>" class="btn btn-info waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            visibility
                                            </span></a>
                                        <a href="<?php echo e(route('admin.pages.edit', $item->id)); ?>" class="btn btn-info waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            edit_note
                                            </span></a>
                                    <form action="<?php echo e(route('admin.pages.destroy', $item->id)); ?>" class="delete_form" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger waves-effect pull-right btn-sm" style="color: white;"><span class="material-symbols-outlined">
                                            delete
                                            </span></button>
                                    </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- #END# Basic Examples -->
</div>
<!-- Button to Open the Modal -->

 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
     $(document).ready(function() {
        $('.isActiveCheckbox').on('change', function() {
            var isActive = $(this).is(':checked');
            var url = $(this).attr('data-url');

            $.ajax({
                url: url,
                type: "POST",
                data: {
                    isActive: isActive,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(res) {
                    Toast.fire({
                        icon: 'success',
                        title: res.msg
                    });
                },
                error: function(xhr, status, error) {
                    // Handle error response if needed
                }
            });
        });
    });
</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make("backend.layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/backend/pages/index.blade.php ENDPATH**/ ?>