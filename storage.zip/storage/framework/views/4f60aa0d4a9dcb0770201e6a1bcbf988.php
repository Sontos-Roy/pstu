<div class="col-sm-12" style="overflow-x:auto;">
    <div class="panel panel-default">
        <div class="panel-heading" style="color: white; background: #213e5e">Department of <?php echo e($department->name); ?></div>
        <div class="panel-body">
            <table class="table table-bordered table-style table-striped">
                <tbody>
                    <tr style="background: #213e5e;color: white">
                        <th class="width-15per">Exam. Name</th>
                        <th class="width-10per">Academic Year</th>
                        <th>Class Start Date</th>
                        <th>First Mid Term</th>
                        <th>Second Mid Term</th>
                        <th>Class Completion Date </th>
                        <th>Field Work Date </th>
                        <th>Final Exam Start Date</th>
                        <th class="width-10per">Final Exam End  Date (Appox.)</th>
                    </tr>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->academic_year); ?></td>
                        <td><?php echo e($item->class_start); ?></td>
                        <td><?php echo e($item->first_mid_term); ?></td>
                        <td><?php echo e($item->second_mid_term); ?></td>
                        <td><?php echo e($item->field_work); ?></td>
                        <td><?php echo e($item->class_completion); ?></td>
                        <td><?php echo e($item->final_exam_start); ?></td>
                        <td><?php echo e($item->final_exam_end); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h2>Empty</h2>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/frontend/calendars/partials.blade.php ENDPATH**/ ?>