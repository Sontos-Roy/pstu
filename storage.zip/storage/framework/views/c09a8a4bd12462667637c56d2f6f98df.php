<aside id="leftsidebar" class="sidebar">
    <!-- User Info -->
    <div class="user-info">
        <div class="admin-image"> <img src="<?php echo e(getImage('teachers', Auth::user()->image)); ?>" alt=""> </div>
        <div class="admin-action-info">
            <h3><?php echo e(Auth::user()->name); ?></h3>
            <?php
                $user = Auth::user();

                // Get the roles of the user
                $roles = $user->roles;

            ?>
            <span><?php echo e($roles->first()->name); ?></span>
            <ul>

                <li><a data-placement="bottom" title="Go to Profile" href="<?php echo e(route('admin.users.show', Auth::id())); ?>"><i class="zmdi zmdi-account"></i></a></li>
                <li><a href="<?php echo e(route('admin.settings.index')); ?>" class="js-right-sidebar" data-close="true"><i class="zmdi zmdi-settings"></i></a></li>
                <li>
                    <a data-placement="bottom" title="Logout" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">
                     
                     <i class="zmdi zmdi-sign-in"></i>  Logout
                 </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </div>
    </div>
    <!-- #User Info -->
    <!-- Menu -->
    <div class="menu">
        <ul class="list">
            <li class="header">MAIN NAVIGATION</li>
            <li class=""><a href="<?php echo e(route('admin.home')); ?>"><i class="zmdi zmdi-home"></i><span>Dashboard</span></a></li>
            <?php
                $teacher = ['admin.users.index', 'admin.users.create'];
            ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.view')): ?>
            <li class="<?php echo e(in_array($currentUrl, $teacher) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-account"></i><span>Users</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.users.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.users.index')); ?>">All Users</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.users.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.users.create')); ?>">Add Users</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>


            <?php
                $deg = ['admin.designations.index', 'admin.designations.create'];
            ?>

            <?php if(auth()->user()->can('designations.view') || auth()->user()->can('designations.create')): ?>

            <li class="<?php echo e(in_array($currentUrl, $deg) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-account"></i><span> Designation </span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('designations.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.designations.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.designations.index')); ?>">All  Designation </a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('designations.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.designations.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.designations.create')); ?>">Add  Designation </a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>


            <?php
                $noc = ['admin.noces.index', 'admin.noces.create'];
            ?>

            <?php if(auth()->user()->can('noces.view') || auth()->user()->can('noces.create')): ?>

            <li class="<?php echo e(in_array($currentUrl, $noc) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-account"></i><span> NOC </span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('noces.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.noces.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.noces.index')); ?>">All  NOC </a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('noces.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.noces.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.noces.create')); ?>">Add  NOC </a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>



            <?php
                $leaders = ['admin.leadership.index', 'admin.leadership.create'];
            ?>

            <?php if(auth()->user()->can('leadership.view') || auth()->user()->can('leadership.create')): ?>

            <li class="<?php echo e(in_array($currentUrl, $leaders) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-account"></i><span>LeaderShips</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('leadership.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.leadership.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.leadership.index')); ?>">All LeaderShips</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('leadership.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.leadership.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.leadership.create')); ?>">Add LeaderShip</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>


            <?php
                $pages = ['admin.pages.index', 'admin.pages.create'];
            ?>

            <?php if(auth()->user()->can('pages.view') || auth()->user()->can('pages.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $pages) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-book"></i><span>Pages</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pages.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.pages.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.pages.index')); ?>">All Pages</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pages.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.pages.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.pages.create')); ?>">Add Pages</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            <?php
                $front = ['admin.sliders.index', 'admin.historical-outline.index', 'admin.university-glance.index', 'admin.honoris-causas.index', 'admin.vice-chanchellors.index', 'admin.university-ordinances.index', 'admin.missionvision.index', 'admin.home_block_types.index'];
            ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-sliders')): ?>
            <li class="<?php echo e(in_array($currentUrl, $front) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-copy"></i><span>Front End</span> </a>
                <ul class="ml-menu">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sliders.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.sliders.index']) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.sliders.index')); ?>">Home Slider</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('historical-outline.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.historical-outline.index']) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.historical-outline.index')); ?>">Historical Outline</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('university-glance.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.university-glance.index']) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.university-glance.index')); ?>">University Glance</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('honoris-causas.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.honoris-causas.index']) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.honoris-causas.index')); ?>">Honoris Causas</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vice-chanchellors.view')): ?>

                    <li class="<?php echo e(in_array($currentUrl, ['admin.vice-chanchellors.index']) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.vice-chanchellors.index')); ?>">Vice Chancellors</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('university-ordinances.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.university-ordinances.index']) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.university-ordinances.index')); ?>">University Ordinances</a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('missionvision.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.missionvision.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.missionvision.index')); ?>">Vision & Mission</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('home_block_types.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.home_block_types.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.home_block_types.index')); ?>">Home Blocks </a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            <?php
                $department = ['admin.department.index', 'admin.department.create'];
            ?>
            <?php if(auth()->user()->can('department.view') || auth()->user()->can('department.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $department) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-city-alt"></i><span>Departments</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('department.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.department.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.department.index')); ?>">All Departments</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('department.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.department.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.department.create')); ?>">Add Departments</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php
                $institutes = ['admin.institutes.index', 'admin.institutes.create'];
            ?>

            <?php if(auth()->user()->can('institutes.view') || auth()->user()->can('institutes.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $institutes) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-city-alt"></i><span>Institutes</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('institutes.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.institutes.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.institutes.index')); ?>">All Institute</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('institutes.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.institutes.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.institutes.create')); ?>">Add Institute</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php
                $students = ['admin.students-page.index', 'admin.students-page.create'];
            ?>
            <?php if(auth()->user()->can('students-page.view') || auth()->user()->can('students-page.create')): ?>

            <?php endif; ?>
            <li class="<?php echo e(in_array($currentUrl, $students) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-city-alt"></i><span>Students Page</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.students-page.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.students-page.index')); ?>">All Student Pages</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.students-page.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.students-page.create')); ?>">Add Student Pages</a></li>
                </ul>
            </li>

            <?php
                $faculties = ['admin.faculties.index', 'admin.faculties.create'];
            ?>
            <?php if(auth()->user()->can('faculties.view') || auth()->user()->can('faculties.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $faculties) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-city-alt"></i><span>Faculties</span> </a>
                <ul class="ml-menu">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faculties.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.faculties.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.faculties.index')); ?>">All Faculties</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('faculties.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.faculties.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.faculties.create')); ?>">Add Faculty</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            <?php
                $programs = ['admin.programs.index', 'admin.programs.create'];
            ?>

            <?php if(auth()->user()->can('programs.view') || auth()->user()->can('programs.create')): ?>

            <li class="<?php echo e(in_array($currentUrl, $programs) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-city-alt"></i><span>Programs</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('programs.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.programs.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.programs.index')); ?>">All Programs</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('programs.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.programs.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.programs.create')); ?>">Add Program</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php
                $news = ['admin.news.index', 'admin.news.add'];
                $events = ['admin.events.index', 'admin.events.create'];
                $notices = ['admin.notices.index', 'admin.notices.create'];
                $admissions = ['admin.admissions.index', 'admin.admissions.create'];
                $libraries = ['admin.libraries.index', 'admin.libraries.create'];
                $academic_calendars = ['admin.academic_calendars.index', 'admin.academic_calendars.create'];
                $offices = ['admin.offices.index', 'admin.offices.create'];
                $researchs = ['admin.researchs.index', 'admin.researchs.create', 'admin.research_center.index', 'admin.research_center.create'];
            ?>

            <?php if(auth()->user()->can('offices.view') || auth()->user()->can('offices.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $offices) ? 'active open' : ''); ?>">
                <a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Offices</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('offices.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.offices.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.offices.index')); ?>">Office List</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('offices.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.offices.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.offices.create')); ?>">Add office</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('news.view') || auth()->user()->can('news.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $news) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>News</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.news.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.news.index')); ?>">News List</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.news.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.news.create')); ?>">Add News</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('libraries.view') || auth()->user()->can('libraries.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $libraries) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Library</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('libraries.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.libraries.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.libraries.index')); ?>">Libraries List</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('libraries.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.libraries.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.libraries.create')); ?>">Add Library</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('academic_calendars.view') || auth()->user()->can('academic_calendars.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $academic_calendars) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Academic Calendars</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('academic_calendars.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.academic_calendars.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.academic_calendars.index')); ?>">Calendar List</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('academic_calendars.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.academic_calendars.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.academic_calendars.create')); ?>">Add Calender</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('events.view') || auth()->user()->can('events.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $events) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Events</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('events.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.events.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.events.index')); ?>">Event List</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('events.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.events.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.events.create')); ?>">Add Event</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('notices.view') || auth()->user()->can('notices.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $notices) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Notices</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notices.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.notices.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.notices.index')); ?>">Notice List</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notices.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.notices.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.notices.create')); ?>">Add Notice</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('admissions.view') || auth()->user()->can('admissions.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $admissions) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Admissions</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admissions.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.admissions.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.admissions.index')); ?>">Admissions List</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admissions.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.admissions.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.admissions.create')); ?>">Create Admissions</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
                <?php
                    $committee = ['admin.regent_board.index', 'admin.planning_work_committee.index', 'admin.academic_council.index', 'admin.finance_committee.index'];
                ?>
            <?php if(auth()->user()->can('regentboard.view') || auth()->user()->can('planning.work.view') || auth()->user()->can('academic.council.view') || auth()->user()->can('finance.committee.view')): ?>
            <li class="<?php echo e(in_array($currentUrl, $committee) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>University Governance</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('regentboard.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.regent_board.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.regent_board.index')); ?>">Regent Board Committees</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('planning.work.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.planning_work_committee.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.planning_work_committee.index')); ?>">Planing Work Committees</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('academic.council.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.academic_council.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.academic_council.index')); ?>">Academic Council</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance.committee.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.finance_committee.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.finance_committee.index')); ?>">Finance Committees</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('researchs.view') || auth()->user()->can('researchs.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $researchs) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Researches</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('researchs.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.researchs.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.researchs.index')); ?>">Research List</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('researchs.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.researchs.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.researchs.create')); ?>">Add Research</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            <?php if(auth()->user()->can('researchs.view') || auth()->user()->can('researchs.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, $researchs) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Research Centers</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('researchs.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.research_center.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.research_center.index')); ?>">Centers List</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('researchs.create')): ?>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.research_center.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.research_center.create')); ?>">Add Research Center</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php
                $permissions = ['admin.permissions.index', 'admin.permissions.add'];
                $roles = ['admin.roles.index', 'admin.roles.create'];
            ?>

            <?php if(auth()->user()->can('permissions.view') || auth()->user()->can('roles.view')): ?>
            <li class="<?php echo e(in_array($currentUrl, $permissions) || in_array($currentUrl, $roles) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-key"></i><span>Role & Permissions</span> </a>
                <ul class="ml-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, $permissions) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.permissions.index')); ?>">All Permissions</a></li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.view')): ?>
                    <li class="<?php echo e(in_array($currentUrl, $roles) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.roles.index')); ?>">All Roles</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('images.view') || auth()->user()->can('images.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, ['admin.images.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.images.index')); ?>"><i class="zmdi zmdi-view-web"></i><span>Images</span></a></li>
            <?php endif; ?>

            <?php if(auth()->user()->can('settings.view') || auth()->user()->can('settings.create')): ?>
            <li class="<?php echo e(in_array($currentUrl, ['admin.settings.index']) ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.settings.index')); ?>"><i class="zmdi zmdi-settings"></i><span>Settings</span></a></li>
            <?php endif; ?>


            <li style="height: 100px;">
                 
            </li>

        </ul>
    </div>
    <!-- #Menu -->
</aside>
<?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/backend/layouts/partials/sidebar.blade.php ENDPATH**/ ?>