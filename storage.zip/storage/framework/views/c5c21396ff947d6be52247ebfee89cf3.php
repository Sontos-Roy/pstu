<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo e(config('app.name', 'Laravel')); ?></title>

<!-- Favicon-->
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="<?php echo e(asset('backend/plugins/bootstrap/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<!-- Custom Css -->
<link rel="stylesheet" href="<?php echo e(asset('backend/css/main.css')); ?>">
<link href="<?php echo e(asset('backend/css/login.css')); ?>" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('backend/css/themes/all-themes.css')); ?>"/>
</head>
<body class="login-page authentication">

<div class="container">
    
    <?php echo $__env->yieldContent('content'); ?>
</div>
<div class="theme-bg"></div>
<!-- Jquery Core Js -->
<script src="<?php echo e(asset('backend/bundles/libscripts.bundle.js')); ?>"></script> <!-- Lib Scripts Plugin Js -->
<script src="<?php echo e(asset('backend/bundles/vendorscripts.bundle.js')); ?>"></script> <!-- Lib Scripts Plugin Js -->
<script src="<?php echo e(asset('backend/bundles/mainscripts.bundle.js')); ?>"></script><!-- Custom Js -->
</body>
</html>
<?php /**PATH D:\xampp\htdocs\pstu-main\resources\views/backend/layouts/app2.blade.php ENDPATH**/ ?>