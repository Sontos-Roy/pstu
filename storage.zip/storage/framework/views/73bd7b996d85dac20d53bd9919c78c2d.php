<?php $__env->startSection('content'); ?>
<style>
    .profile-page .profile-header .profile_info .profile-image img{
        aspect-ratio: 3/3;
        height: 250px;
    }
</style>
<div class="container-fluid profile-page">
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="boxs-simple">
                <div class="profile-header" style="background:rgba(0,0,0,0) url(<?php echo e(asset('backend/images/profile-bg.jpg')); ?>) repeat scroll center center/cover;">
                    <div class="profile_info">
                        <div class="profile-image"> <img src="<?php echo e(getImage('teachers', $teacher->userDetails ? $teacher->userDetails->image : '')); ?>" alt=""> </div>
                        <h4 class="mb-0"><strong><?php echo e($teacher->name); ?></strong></h4>
                        <span class="text-muted col-white"><?php echo e($teacher->userDetails->position); ?></span>
                        <p class="social-icon">
                            <a title="Twitter" href="<?php echo e($teacher->userDetails->twitter); ?>"><i class="zmdi zmdi-twitter"></i></a>
                            <a title="Facebook" href="<?php echo e($teacher->userDetails->facebook); ?>"><i class="zmdi zmdi-facebook"></i></a>
                            <a title="Youtube" href="<?php echo e($teacher->userDetails->youtube); ?>"><i class="zmdi zmdi-youtube"></i></a>
                            <a title="Website" href="<?php echo e($teacher->userDetails->website); ?>"><i class="zmdi zmdi-globe-alt"></i></a>
                            <a title="Google Plus" href="<?php echo e($teacher->userDetails->google_plus); ?>"><i class="zmdi zmdi-google "></i></a>
                            <a title="LinkedIn" href="<?php echo e($teacher->userDetails->linkedin); ?>"><i class="zmdi zmdi-linkedin"></i></a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="body">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">

                        <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#usersettings">Setting</a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">

                        <div role="tabpanel" class="tab-pane in active" id="usersettings">
                            <h2 class="card-inside-title">Security Settings</h2>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-teachers')): ?>
                            <form action="">
                                <div class="row clearfix">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e($teacher->email); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="password" name="current_password" class="form-control" placeholder="Current Password">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="password" name="password" class="form-control" placeholder="New Password">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-line">
                                                <input type="cpassword" name="confirm_password" class="form-control" placeholder="New Password">
                                            </div>
                                        </div>
                                        <button class="btn btn-raised g-bg-blush2">Save Changes</button>
                                    </div>
                                </div>
                            </form>
                            <?php endif; ?>
                            <h2 class="card-inside-title">  </h2>
                            <a href="<?php echo e(route('admin.users.edit', $teacher->id)); ?>" class="btn btn-info text-white">
                                <div class="d-flex align-items-center">
                                   View &  Edit Profile <span class="material-symbols-outlined pl-2"> edit_note </span>
                                </div>
                            </a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstu\resources\views/backend/teachers/view.blade.php ENDPATH**/ ?>