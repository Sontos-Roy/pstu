<aside id="leftsidebar" class="sidebar">
    <!-- User Info -->
    <div class="user-info">
        <div class="admin-image"> <img src="<?php echo e(getImage('teachers', Auth::user()->image)); ?>" alt=""> </div>
        <div class="admin-action-info">
            <h3><?php echo e(Auth::user()->name); ?></h3>
            <?php
                $user = Auth::user();

                // Get the roles of the user
                $roles = $user->roles;

            ?>
            <span><?php echo e($roles->first()->name); ?></span>
            <ul>

                <li><a data-placement="bottom" title="Go to Profile" href="<?php echo e(route('admin.users.show', Auth::id())); ?>"><i class="zmdi zmdi-account"></i></a></li>
                <li><a href="<?php echo e(route('admin.settings.index')); ?>" class="js-right-sidebar" data-close="true"><i class="zmdi zmdi-settings"></i></a></li>
                <li>
                    <a data-placement="bottom" title="Logout" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">
                     
                     <i class="zmdi zmdi-sign-in"></i>
                 </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </div>
    </div>
    <!-- #User Info -->
    <!-- Menu -->
    <div class="menu">
        <ul class="list">
            <li class="header">MAIN NAVIGATION</li>
            <li class=""><a href="<?php echo e(route('admin.home')); ?>"><i class="zmdi zmdi-home"></i><span>Dashboard</span></a></li>
            <?php
                $teacher = ['admin.users.index', 'admin.users.create'];
            ?>
            <li class="<?php echo e(in_array($currentUrl, $teacher) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-account"></i><span>Professors</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.users.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.users.index')); ?>">All Professors</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.users.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.users.create')); ?>">Add professors</a></li>
                </ul>
            </li>
            <?php
                $leaders = ['admin.leadership.index', 'admin.leadership.create'];
            ?>
            <li class="<?php echo e(in_array($currentUrl, $leaders) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-account"></i><span>LeaderShips</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.leadership.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.leadership.index')); ?>">All LeaderShips</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.leadership.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.leadership.create')); ?>">Add LeaderShip</a></li>
                </ul>
            </li>
            <?php
                $pages = ['admin.pages.index', 'admin.pages.create'];
            ?>
            <li class="<?php echo e(in_array($currentUrl, $pages) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-book"></i><span>Pages</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.pages.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.pages.index')); ?>">All Pages</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.pages.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.pages.create')); ?>">Add Pages</a></li>
                </ul>
            </li>
            <?php
                $front = ['admin.sliders.index', 'admin.historical-outline.index', 'admin.university-glance.index', 'admin.honoris-causas.index', 'admin.vice-chanchellors.index', 'admin.university-ordinances.index'];
            ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-sliders')): ?>
            <li class="<?php echo e(in_array($currentUrl, $front) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-copy"></i><span>Front End</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.sliders.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.sliders.index')); ?>">Home Slider</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.historical-outline.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.historical-outline.index')); ?>">Historical Outline</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.university-glance.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.university-glance.index')); ?>">University Glance</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.honoris-causas.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.honoris-causas.index')); ?>">Honoris Causas</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.vice-chanchellors.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.vice-chanchellors.index')); ?>">Vice Chancellors</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.university-ordinances.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.university-ordinances.index')); ?>">University Ordinances</a></li>
                </ul>
            </li>
            <?php endif; ?>
            <?php
                $department = ['admin.department.index', 'admin.department.create'];
            ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-department')): ?>
            <li class="<?php echo e(in_array($currentUrl, $department) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-city-alt"></i><span>Departments</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.department.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.department.index')); ?>">All Departments</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.department.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.department.create')); ?>">Add Departments</a></li>
                </ul>
            </li>
            <?php endif; ?>
            <?php
                $students = ['admin.students-page.index', 'admin.students-page.create'];
            ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-department')): ?>
            <li class="<?php echo e(in_array($currentUrl, $students) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-city-alt"></i><span>Students Page</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.students-page.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.students-page.index')); ?>">All Student Pages</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.students-page.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.students-page.create')); ?>">Add Student Pages</a></li>
                </ul>
            </li>
            <?php endif; ?>
            <?php
                $faculties = ['admin.faculties.index', 'admin.faculties.create'];
            ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-department')): ?>
            <li class="<?php echo e(in_array($currentUrl, $faculties) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-city-alt"></i><span>Faculties</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.faculties.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.faculties.index')); ?>">All Faculties</a></li>

                    <li class="<?php echo e(in_array($currentUrl, ['admin.faculties.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.faculties.create')); ?>">Add Faculty</a></li>
                </ul>
            </li>
            <?php endif; ?>
            <?php
                $programs = ['admin.programs.index', 'admin.programs.create'];
            ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-department')): ?>
            <li class="<?php echo e(in_array($currentUrl, $programs) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-city-alt"></i><span>Programs</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.programs.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.programs.index')); ?>">All Programs</a></li>

                    <li class="<?php echo e(in_array($currentUrl, ['admin.programs.create']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.programs.create')); ?>">Add Program</a></li>
                </ul>
            </li>
            <?php endif; ?>

            <?php
                $news = ['admin.news.index', 'admin.news.add'];
                $events = ['admin.events.index', 'admin.events.create'];
                $notices = ['admin.notices.index', 'admin.notices.create'];
            ?>
            <li class="<?php echo e(in_array($currentUrl, $news) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>News</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.news.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.news.index')); ?>">News List</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.news.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.news.create')); ?>">Add News</a></li>
                </ul>
            </li>
            <li class="<?php echo e(in_array($currentUrl, $events) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Events</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.events.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.events.index')); ?>">Event List</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.events.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.events.create')); ?>">Add Event</a></li>
                </ul>
            </li>
            <li class="<?php echo e(in_array($currentUrl, $notices) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-view-web"></i><span>Notices</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, ['admin.notices.index']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.notices.index')); ?>">Notice List</a></li>
                    <li class="<?php echo e(in_array($currentUrl, ['admin.notices.create']) ? 'active' : ''); ?>"> <a href="<?php echo e(route('admin.notices.create')); ?>">Add Notice</a></li>
                </ul>
            </li>
            <?php
                $permissions = ['admin.permissions.index', 'admin.permissions.add'];
                $roles = ['admin.roles.index', 'admin.roles.create'];
            ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("add-roles")): ?>
            <li class="<?php echo e(in_array($currentUrl, $permissions) || in_array($currentUrl, $roles) ? 'active open' : ''); ?>"><a href="javascript:void(0);" class="menu-toggle"><i class="zmdi zmdi-key"></i><span>Role & Permissions</span> </a>
                <ul class="ml-menu">
                    <li class="<?php echo e(in_array($currentUrl, $permissions) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.permissions.index')); ?>">All Permissions</a></li>
                    <li class="<?php echo e(in_array($currentUrl, $roles) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.roles.index')); ?>">All Roles</a></li>
                </ul>
            </li>
            <?php endif; ?>


            <li class="<?php echo e(in_array($currentUrl, ['admin.settings.index']) ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.settings.index')); ?>"><i class="zmdi zmdi-settings"></i><span>Settings</span></a></li>
            <li style="height: 100px;">
                 
            </li>

        </ul>
    </div>
    <!-- #Menu -->
</aside>
<?php /**PATH G:\xampp\htdocs\pstu\resources\views/backend/layouts/partials/sidebar.blade.php ENDPATH**/ ?>