    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.sliders.update', $data->id)); ?>" method="POST" id="ajax_form">
            <div class="modal-header">
                <h4 class="modal-title" id="createsettingLabel">Slider Edit</h4>
            </div>
            <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="container">
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Head Text</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="head" value="<?php echo e($data->head); ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">First Button</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="first_btn" value="<?php echo e($data->first_btn); ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Second Button</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="second_btn" value="<?php echo e($data->second_btn); ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">First Button Link</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="first_btn_link" value="<?php echo e($data->first_btn_link); ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Second Button Link</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" style="border: 1px solid black;" name="second_btn_link" value="<?php echo e($data->second_btn_link); ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="" class="col-4 col-form-label">Select For</label>
                                <div class="col-8">
                                        <select class="form-control shadow-none" name="select_for" id="select_for">
                                            <option selected>Select one</option>
                                            <option value="main" <?php echo e($data->select_for == 'main' ? 'selected' : ''); ?>>Main Page</option>
                                            <option value="faculty" <?php echo e($data->select_for == 'faculty' ? 'selected' : ''); ?>>Faculty Section</option>
                                            <option value="department" <?php echo e($data->select_for == 'department' ? 'selected' : ''); ?>>Department Section</option>
                                        </select>
                                </div>
                            </div>
                            <div class="mb-3 row faculty">
                                <label for="" class="col-4 col-form-label">Select Faculty</label>
                                <div class="col-8">
                                        <select class="form-control shadow-none" name="faculty_id" id="">
                                            <option value="">Select one</option>
                                            <?php $__currentLoopData = getFaculty(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($faculty->id); ?>" <?php echo e($faculty->id == $data->faculty_id ? 'selected' : ''); ?>><?php echo e($faculty->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                            </div>
                            <div class="mb-3 row department">
                                <label for="" class="col-4 col-form-label">Select Department</label>
                                <div class="col-8">
                                        <select class="form-control shadow-none" name="department_id" id="">
                                            <option value="">Select one</option>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>" <?php echo e($department->id == $data->department_id ? 'selected' : ''); ?>><?php echo e($department->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputName" class="col-4 col-form-label">Slider Active Or Not</label>
                                <div class="switch">
                                    <label class="d-flex">OFF
                                        <input type="checkbox" <?php echo e($data->isActive == 1 ? 'checked' : ''); ?> name="isActive">
                                        <span class="lever"></span>ON</label>
                                 </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="inputName" class="col-4 col-form-label">Type</label>
                                <div class="col-8">
                                    <input type="file" class="form-control" style="border: 1px solid black;" name="image">
                                </div>
                            </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
                    <button type="submit" class="btn btn-link waves-effect">SAVE CHANGES</button>
                </div>
            </form>
            </div>
        </div>
<?php /**PATH /home/cloudho1/public_html/pstulive/resources/views/backend/homeSlider/edit.blade.php ENDPATH**/ ?>