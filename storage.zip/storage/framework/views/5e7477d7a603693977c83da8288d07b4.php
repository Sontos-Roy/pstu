<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area shadow dark text-center text-light" style="background-image: url('<?php echo e(getImage('settings', getSetting('pagebanner1'))); ?>'); background-size: cover; background-repeat: no-repeat;padding: 103px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <h2>Head Of Offices</h2>
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('front.home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                    <li class="active">Head Of Offices</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="advisor-area bg-gray default-padding bottom-less bg-cover">
    <div class="container">
        <div class="row">
            <div class="advisor-items col-3 text-light text-center">
                <?php $__currentLoopData = $officers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6 single-item">
                    <a href="<?php echo e(route('front.officers.show', $item->id)); ?>">
                    </a>
                    <div class="item">
                        <a href="<?php echo e(route('front.officers.show', $item->id)); ?>">
                            <div class="thumb">
                                <img src="<?php echo e(getImage('teachers', $item->user->userDetails->image)); ?>" alt="Thumb">
                            </div>
                        </a>
                        <div class="info" style="height: 140px">
                            <a href="<?php echo e(route('front.officers.show', $item->id)); ?>">
                            </a><a href="<?php echo e(route('front.officers.show', $item->id)); ?>">
                            <span>Head Of <?php echo e($item->name); ?></span>
                            </a>
                            <h4>
                                <a href="<?php echo e(route('front.officers.show', $item->id)); ?>" target="_blank"> <?php echo e($item->user->name); ?>

                                </a>
                            </h4>
                            <span>
                            </span>
                        </div>
                        <div class="text-center">
                            <a class="btn circle btn-dark border btn-sm" href="<?php echo e(route('front.officers.show', $item->id)); ?>" style="margin:10px;">Read More...<i class="fas fa-check-circle fa-2x fa-pull-right"></i></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/frontend/offices/officers.blade.php ENDPATH**/ ?>