<div class="top-bar-area bg-dark text-light">
    <div class="container">
        <div class="row">
            <div class="col-md-3 logo-box">
                <a href="<?php echo e(route('front.home')); ?>"><img src="<?php echo e(getImage('settings', getSetting('logo'))); ?>" alt="Thumb" height="40"></a>
            </div>
            <div class="col-md-6">
                <a href=""> <span class="deptHeading">Department of <?php echo $__env->yieldPushContent('department'); ?></span> </a>
            </div>
            <div class="col-md-3 link text-right">
                <ul>
                    <li>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Header
============================================= -->
<header id="home">

    <!-- Start Navigation -->
    <nav class="navbar top-pad navbar-default attr-border-none navbar-fixed navbar-transparent white bootsnav">


        <!-- End Top Search -->

        <div class="container">

            <!-- End Atribute Navigation -->

            <!-- Start Header Navigation -->

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                <i class="fa fa-bars"></i>
                </button>

            </div>
            <!-- End Header Navigation -->

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar-menu">
                <ul class="nav navbar-nav navbar-left" data-in="#" data-out="#">
                    <li>
                        <a href="<?php echo e(route('front.home')); ?>" class="dropdown-toggle" data-toggle="dropdown">Home</a>
                        <ul class="dropdown-menu animated #">
                            <li></li>
                        </ul>
                    </li>
                    <li class="dropdown on">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">About</a>
                        <ul class="dropdown-menu animated #">
                            <li><a href="<?php echo e(route('front.departments.mission', [request()->segment(2)])); ?>">Mission &amp; Vision</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Academic</a>
                        <ul class="dropdown-menu animated">
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Programs</a>
                                <ul class="dropdown-menu animated">
                                    <li><a href="">BS in Applied Mathematics</a></li>
                                    <li><a href="">MS in Applied Mathematics</a></li>
                                    <li><a href="">MPhil in Applied Mathematics</a></li>
                                    <li><a href="">PhD in Applied Mathematics</a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('front.departments.calendar', [request()->segment(2)])); ?>">Academic Calendar</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">People</a>
                        <ul class="dropdown-menu animated">
                            <li><a href="">Faculty Members</a></li>
                            <li><a href="">Officers and Staff</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"> Research</a>
                        <ul class="dropdown-menu animated">
                            <li><a href="">Research Area</a></li>
                            <li><a href="">Funded Projects</a></li>
                            <li><a href="">Publications</a></li>
                            <li><a href="">Research Facilities</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Student</a>
                        <ul class="dropdown-menu animated">
                            <li><a href="">Student Activities</a></li>
                            <li><a href="">Student Achievements</a></li>
                            <li><a href="">Scholarships &amp; Financial Aids</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Alumni</a>
                        <ul class="dropdown-menu animated">
                            <li><a href="">Notable Alumni</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
    </nav>        <!-- End Navigation -->

</header>
<?php /**PATH G:\xampp\htdocs\pstulive\resources\views/frontend/partials/department_header.blade.php ENDPATH**/ ?>