<?php $__env->startSection('content'); ?>
 <!-- Start Banner
    ============================================= -->
    <div class="banner-area">
        <div id="bootcarousel" class="carousel text-center content-less text-light top-pad-30 text-dark slide animate_text" data-ride="carousel">

            <!-- Wrapper for slides -->
            <div class="carousel-inner carousel-zoom">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item <?php echo e($key == 0 ? 'active': ''); ?> bg-cover" style="background-image: url('<?php echo e(getImage('sliders', $item->image)); ?>');">
                    <div class="box-table">
                        <div class="box-cell shadow dark">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-10 col-md-offset-1">
                                        <div class="content">
                                            <h2 data-animation="animated fadeInLeft"><?php echo e($item->head); ?></h2>
                                            <?php if($item->first_btn): ?>
                                            <a data-animation="animated fadeInDown" class="btn btn-light border btn-md" href="<?php echo e($item->first_btn_link); ?>"><?php echo e($item->first_btn); ?></a>
                                            <?php endif; ?>
                                            <?php if($item->second_btn): ?>
                                            <a data-animation="animated fadeInUp" class="btn btn-light effect btn-md" href="<?php echo e($item->second_btn_link); ?>"><?php echo e($item->second_btn); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- End Wrapper for slides -->

            <!-- Left and right controls -->
            <a class="left carousel-control shadow" href="#bootcarousel" data-slide="prev">
                <i class="fa fa-angle-left"></i>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control shadow" href="#bootcarousel" data-slide="next">
                <i class="fa fa-angle-right"></i>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <div class="row" style="margin-top:50px"></div>
    <!-- End Banner -->
    <div class="features-area">
        <div class="container">
            <div class="row">
                <div class="features">
                    <div data-aos="fade-left" class="equal-height col-md-3 col-sm-6 aos-init aos-animate" style="height: 300px;">
                        <div class="item mariner">
                            <a href="vc.html">
                                <div style="height: 200px;" class="info">
                                    <p>
                                        <img src="<?php echo e(getImage('teachers', $vc->user->userDetails->image)); ?>" height="180" width="200" alt=" Vice Chancellor" srcset="">

                                    </p>
                                    <p style="font-weight: bold; font-size: 12px; text-align: center;">
                                        <?php echo e($vc->name); ?></p>
                                    <h5 class="text-center"><strong><?php echo e($vc->designation); ?></strong></h5>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div data-aos="fade-up" class="equal-height col-md-9 col-sm-6 aos-init aos-animate" style="height: 300px;">
                        <div class="item brilliantrose">
                            <a href="vc.html" >
                                <div style="height: 200px; overflow: hidden;" class="info">
                                    <h4>Message from the <?php echo e($vc->designation); ?></h4>
                                    <p class="text-justify">
                                        <?php echo e($vc->message_short); ?>


                                    </p>
                                </div>
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="features-area  bottom-less">
        <div class="container">
            <div class="row">
                <div class="features">
                    <?php $__currentLoopData = $leaderships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="text-align: center; height: 320px;" data-aos="fade-left" class="equal-height col-md-4 col-sm-6 aos-init aos-animate">
                        <div class="item mariner">
                            <a href="">
                                <div style="height: 220px;" class="info">
                                    <p>
                                        <img src="<?php echo e(getImage('teachers', $item->user->userDetails->image)); ?>" height="180" width="200" alt="<?php echo e($item->designation); ?>" srcset="">

                                    </p>
                                    <p style="font-weight: bold; font-size: 14px;">
                                        <?php echo e($item->name); ?>

                                    </p>
                                    <h5 style="font-weight: bold;"><?php echo e($item->designation); ?></h5>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>

    <!-- End Features -->
    <div class="row" style="margin-top:50px"></div>

    <div class="about-area">
        <div class="container">
            <div class="row">
                <div class="about-items">
                    <div data-aos="fade-down-right" class="col-md-6 about-info aos-init aos-animate">
                        <h3 class="text-justify">
                            Welcome to the Patuakhali Science & Technology University
                        </h3>

                        <p class="text-justify">
                            <?php echo e($page->short); ?>

                        </p>
                        <a class="btn btn-theme effect btn-block btn-lg btnhome" href="<?php echo e(route('front.page.show', $page->slug)); ?>">Read
                            More...<i class="fas fa-check-circle fa-2x fa-pull-right"></i></a>
                    </div>

                    <div data-aos="fade-up-left" class="col-md-6 thumb aos-init aos-animate">
                        <div class="thumb">
                            <img src="<?php echo e(getImage('pages', $page->image)); ?>" alt="Thumb">
                            <a href="<?php echo e($page->video_link); ?>" class="popup-youtube light video-play-button">
                                <i class="fa fa-play"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="blog-area default-padding bottom-less">
        <div class="container">
           <div class="row">
              <div class="site-heading text-center">
                 <div class="col-md-8 col-md-offset-2">
                    <h2>Latest News</h2>
                 </div>
              </div>
           </div>
           <div class="row">
              <div class="blog-items courses-carousel owl-theme owl-carousel">
                 <!-- Single Item -->
                 <!-- End Single Item -->
                 <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div data-aos="zoom-in" data-aos-delay="200" class="single-item aos-init">
                    <div class="item">
                       <div class="thumb">
                          <a href="">
                          <img src="<?php echo e(getImage('news', $news->image)); ?>" style="height: 240px;width: 100%;" alt="<?php echo e($news->heading); ?>">
                          </a>
                       </div>
                       <div class="info">
                          <div class="meta">
                             <ul>
                                <li style="text-transform: capitalize!important;">
                                   <i class="fas fa-calendar-alt"></i>
                                   <?php echo e($news->created_at->diffForHumans()); ?>

                                </li>
                             </ul>
                          </div>
                          <div class="content">
                             <h4 class="text-left" style="height: 80px; word-spacing: 5px">
                                <a href="" title="<?php echo e($news->heading); ?>"><?php echo e(StrLimit($news->heading, 50)); ?></a>
                             </h4>
                             <a href=""><i class="fas fa-plus"></i> Read More</a>
                          </div>
                       </div>
                    </div>
                 </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div>
              <div class="more-btn col-md-12 text-center">
                 <a href="" class="btn btn-theme effect btn-md"> View All News </a>
              </div>
           </div>
        </div>
     </div>

    <div class="popular-courses-area weekly-top-items bottom-less">
        <div class="container">

            <div class="row">
                <div class="top-course-items flex-item">
                    <!-- Single Item -->
                    <div class="col-md-6 col-sm-6 equal-height">
                        <div class="row">
                            <div class="item">
                                <div class="thumb col-md-5" style="background-image: url(<?php echo e(asset('frontend/img/stats.avif')); ?>);">
                                    <div class="overlay">

                                    </div>
                                </div>
                                <div class="info col-md-7">
                                    <h4>
                                        <a href="#">About Us</a>
                                    </h4>
                                    <ul>
                                    <li> <a href="<?php echo e(route('front.historic.outline')); ?>">Historic Outline</a> </li>
                                    <li> <a href="<?php echo e(route('front.university.glance')); ?>">At A Glance</a> </li>
                                    <li> <a href="<?php echo e(route('front.honoris.causa')); ?>">Honoris Causa</a> </li>
                                    <li><a href="<?php echo e(route('front.vice.chencellors.message', 'vice-chancellor')); ?>">Message from the Vice Chancellor</a></li>
                                            <li><a href="<?php echo e(route('front.vice.chencellors')); ?>">List of Vice Chancellors</a></li>

                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-6 col-sm-6 equal-height">
                        <div class="row">
                            <div class="item">
                                <div class="thumb col-md-5" style="background-image: url(<?php echo e(asset('frontend/img/stats2.avif')); ?>);">
                                    <div class="overlay">

                                    </div>
                                </div>
                                <div class="info col-md-7">

                                    <h4>
                                        <a href="#">Leadership</a>
                                    </h4>
                                    <ul>
                                        <?php $__currentLoopData = LeaderShips(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('front.vice.chencellors.message', $item->slug)); ?>"><?php echo e($item->designation); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-6 col-sm-6 equal-height">
                        <div class="row">
                            <div class="item">
                                <div class="thumb col-md-5" style="background-image: url(<?php echo e(asset('frontend/img/gov.avif')); ?>);">
                                    <div class="overlay">

                                    </div>
                                </div>
                                <div class="info col-md-7">
                                    <div class="meta">
                                        <ul>


                                        </ul>
                                    </div>
                                    <h4>
                                        <a href="#">Governance Frameworks</a>
                                    </h4>
                                    <ul>
                                        <li> <a href="<?php echo e(route('front.university.ordinances')); ?>">University Ordinance</a> </li>
                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-6 col-sm-6 equal-height">
                        <div class="row">
                            <div class="item">
                                <div class="thumb col-md-5" style="background-image: url(<?php echo e(asset('frontend/img/academic.avif')); ?>);">
                                    <div class="overlay">

                                    </div>
                                </div>
                                <div class="info col-md-7">
                                    <div class="meta">
                                        <ul>


                                        </ul>
                                    </div>
                                    <h4>
                                        <a href="#">Academics</a>
                                    </h4>
                                    <ul>
                                    <li> <a href="<?php echo e(route('front.programs')); ?>">Programs</a> </li>
                                    <li> <a href="<?php echo e(route('front.faculties')); ?>">Faculties</a> </li>
                                    <li> <a href="<?php echo e(route('front.departments')); ?>">Departments</a> </li>

                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-6 col-sm-6 equal-height">
                        <div class="row">
                            <div class="item">
                                <div class="thumb col-md-5" style="background-image: url(<?php echo e(asset('frontend/img/comp.webp')); ?>);">
                                    <div class="overlay">

                                    </div>
                                </div>
                                <div class="info col-md-7">
                                    <div class="meta">
                                        <ul>


                                        </ul>
                                    </div>
                                    <h4>
                                        <a href="#">Administration</a>
                                    </h4>
                                    <ul>
                                        <li> <a href="<?php echo e(route('front.get.deans')); ?>">Deans</a> </li>
                                        <li> <a href="<?php echo e(route('front.get.heads')); ?>">Chairmans</a> </li>
                                        <li> <a href="">Directors</a> </li>
                                        <li> <a href="">Provosts</a> </li>
                                        <li> <a href="">Wardens</a> </li>
                                        <li> <a href="">Heads</a> </li>

                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single Item -->
                    <!-- Single Item -->
                    <div class="col-md-6 col-sm-6 equal-height">
                        <div class="row">
                            <div class="item">
                                <div class="thumb col-md-5" style="background-image: url(<?php echo e(asset('frontend/img/people.jpg')); ?>);">
                                    <div class="overlay">

                                    </div>
                                </div>
                                <div class="info col-md-7">
                                    <div class="meta">
                                        <ul>


                                        </ul>
                                    </div>
                                    <h4>
                                        <a href="#">Students</a>
                                    </h4>
                                    <ul>
                                        <li> <a href="">Scholarships</a> </li>
                                        <li> <a href="">Transport Facilities</a> </li>
                                        <li> <a href="">Health Insurances</a> </li>
                                        <li> <a href="">Exam Results</a> </li>
                                        <li> <a href="">Alumni</a> </li>
                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Single Item -->
                </div>
            </div>
        </div>
    </div>
    <div class="blog-area default-padding bottom-less">
        <div class="container">
           <div class="row">
              <div class="site-heading text-center">
                 <div class="col-md-8 col-md-offset-2">
                    <h2>Recent and Upcoming Events</h2>
                 </div>
              </div>
           </div>
           <div class="row">
              <div class="blog-items event-carousel owl-theme owl-carousel">
                 <!-- Single Item -->
                 <!-- End Single Item -->
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div data-aos="zoom-in-up" class="equal-height aos-init aos-animate" style="height: 550px;">
                    <div class="item">
                        <div class="thumb">
                            <img src="<?php echo e(getImage('events', $event->image)); ?>" style="height:250px;" alt="<?php echo e($event->heading); ?>">
                        </div>
                        <div class="info">
                            <div class="info-box" style="padding:35px 35px">
                                <div class="date">
                                    <strong style="font-size: 30px"><?php echo e(date('d', strtotime($event->date))); ?></strong>
                                    <?php echo e(date('M, Y', strtotime($event->date))); ?>

                                </div>
                                <br>
                                <div class="content" style="margin-left: 0px; padding: 0">
                                    <h4 class="text-left " style="height: 50px; word-spacing: 5px">
                                        <a href=""><?php echo e(StrLimit($event->heading, 70)); ?></a>
                                    </h4>
                                    <p style="height: 100px">
                                        <?php echo e(StrLimit($event->short, 150)); ?>

                                    </p>
                                    <div class="bottom" style="margin-top: 20px">
                                        <div class="col-sm-12">
                                            <a href="" class="btn circle btn-dark border btn-sm text-center">
                                                <i style="color: #1C4370" class="fas fa-plus"></i> Read More
                                            </a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <br>
              <div class="more-btn col-md-12 text-center">
                <a href="#" class="btn btn-theme effect btn-md">View All Events</a>
            </div>
           </div>
        </div>
     </div>
    <div class="popular-courses-area weekly-top-items bg-gray default-padding bottom-less"  style="display: none;">
        <div class="container">
            <div class="row">
                <div class="site-heading text-center">
                    <div class="col-md-8 col-md-offset-2">
                    <h2> Research Activities</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="top-course-items courses-carousel owl-carousel owl-theme">
                    <div data-aos="fade-up" class="aos-init aos-animate">
                        <div class="item">
                            <div class="thumb">
                                <img src="<?php echo e(asset('frontend/img/1663914862_Volume 11 Issue 1 Cover Page.jpg')); ?>" style="height: 220px" alt="Thumb">
                                <div class="overlay">
                                    <a href="#">
                                    </a>
                                </div>
                            </div>
                            <div class="info">
                                <div class="meta">
                                    <ul>
                                        <li>
                                        </li>
                                        <li>
                                        <a href="#">08 Nov, 2021</a>
                                        </li>
                                    </ul>
                                </div>
                                <h4 class="text-left min-height-130px" style="word-spacing: 5px">
                                    <a href="">Genetic diversity with respect to salt tolerance identified by genome wide study of 176 Bangladeshi traditional rice accessions and published in prestigious journal, PLoS One</a>
                                </h4>
                                <div class="footer-meta text-center">
                                    <a href="" class="btn circle btn-dark border btn-sm text-center">
                                    <i class="fas fa-plus"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-aos="fade-up" class="aos-init aos-animate">
                        <div class="item">
                            <div class="thumb">
                                <img src="<?php echo e(asset('frontend/img/presentation-for-jets-south-korea-biswas-dibyendu-pstu-171030022347-thumbnail.jpg')); ?>" style="height: 220px" alt="Thumb">
                                <div class="overlay">
                                    <a href="#">
                                    </a>
                                </div>
                            </div>
                            <div class="info">
                                <div class="meta">
                                    <ul>
                                        <li>
                                        </li>
                                        <li>
                                        <a href="#">08 Nov, 2021</a>
                                        </li>
                                    </ul>
                                </div>
                                <h4 class="text-left min-height-130px" style="word-spacing: 5px">
                                    <a href="">Genetic diversity with respect to salt tolerance identified by genome wide study of 176 Bangladeshi traditional rice accessions and published in prestigious journal, PLoS One</a>
                                </h4>
                                <div class="footer-meta text-center">
                                    <a href="" class="btn circle btn-dark border btn-sm text-center">
                                    <i class="fas fa-plus"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-aos="fade-up" class="aos-init aos-animate">
                        <div class="item">
                            <div class="thumb">
                                <img src="<?php echo e(asset('frontend/img/Types-of-Research-Methodology.jpg')); ?>" style="height: 220px" alt="Thumb">
                                <div class="overlay">
                                    <a href="#">
                                    </a>
                                </div>
                            </div>
                            <div class="info">
                                <div class="meta">
                                    <ul>
                                        <li>
                                        </li>
                                        <li>
                                        <a href="#">08 Nov, 2021</a>
                                        </li>
                                    </ul>
                                </div>
                                <h4 class="text-left min-height-130px" style="word-spacing: 5px">
                                    <a href="">Genetic diversity with respect to salt tolerance identified by genome wide study of 176 Bangladeshi traditional rice accessions and published in prestigious journal, PLoS One</a>
                                </h4>
                                <div class="footer-meta text-center">
                                    <a href="" class="btn circle btn-dark border btn-sm text-center">
                                    <i class="fas fa-plus"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-aos="fade-up" class="aos-init aos-animate">
                        <div class="item">
                            <div class="thumb">
                                <img src="<?php echo e(asset('frontend/img/What-is-Research-Purpose-of-Research-phul4s3cbwe0xam190dnc4kz3z616ajmfkygodcdqg.png')); ?>" style="height: 220px" alt="Thumb">
                                <div class="overlay">
                                    <a href="#">
                                    </a>
                                </div>
                            </div>
                            <div class="info">
                                <div class="meta">
                                    <ul>
                                        <li>
                                        </li>
                                        <li>
                                        <a href="#">08 Nov, 2021</a>
                                        </li>
                                    </ul>
                                </div>
                                <h4 class="text-left min-height-130px" style="word-spacing: 5px">
                                    <a href="">Genetic diversity with respect to salt tolerance identified by genome wide study of 176 Bangladeshi traditional rice accessions and published in prestigious journal, PLoS One</a>
                                </h4>
                                <div class="footer-meta text-center">
                                    <a href="" class="btn circle btn-dark border btn-sm text-center">
                                    <i class="fas fa-plus"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="more-btn col-md-12 text-center" style="padding-top: 20px; margin-top: 20px;">
                    <a href="#" class="btn btn-theme effect btn-md">View All Research Activities</a>
                </div>
            </div>
        </div>
    </div>
    <div class="popular-courses-area weekly-top-items bg-gray default-padding bg-cover bottom-less" style="background-image: url(<?php echo e(asset('frontend/img/shape-bg.png')); ?>);">
        <div class="container">
            <div class="row">
                <div class="site-heading text-center">
                    <div class="col-md-8 col-md-offset-2">
                    <h2>Notices</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="top-course-items courses-carousel owl-carousel owl-theme">
                    <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div data-aos="fade-up" class="aos-init aos-animate">
                        <div class="item">

                            <div class="info">
                                <h4 class="text-left min-height-130px" style="word-spacing: 5px; font-size: 17px;">
                                    <a href=""><?php echo e($notice->title); ?></a>
                                </h4>
                                <div class="meta">
                                    <ul>
                                        <li>
                                        <a href="#"><?php echo e(date('d M Y', strtotime($notice->created_at))); ?></a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="footer-meta text-center">
                                    <a href="" class="btn circle btn-dark border btn-sm text-center">
                                    <i class="fas fa-plus"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                <div class="more-btn col-md-12 text-center" style="padding-top: 20px; margin-top: 20px;">
                    <a href="<?php echo e(route('front.notices')); ?>" class="btn btn-theme effect btn-md">View All Notices</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row" style="margin-top:50px"></div>
    <!-- Start Popular Courses
    ============================================= -->

    <!-- End Popular Courses -->

    <!-- Start Testimonials
    ============================================= -->

    <!-- End Testimonials -->




<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstu\resources\views/frontend/index.blade.php ENDPATH**/ ?>