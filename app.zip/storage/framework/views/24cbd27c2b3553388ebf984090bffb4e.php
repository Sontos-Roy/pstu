<?php $__env->startSection('content'); ?>
<div class="breadcrumb-area shadow dark text-center text-light" style="background-image: url('<?php echo e(getImage('settings', getSetting('pagebanner1'))); ?>'); background-size: cover; background-repeat: no-repeat;padding: 103px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <h2><?php echo e($item->name); ?></h2>
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('front.home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                    <li class="active"><?php echo e($item->name); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="features-area bottom-less" style="margin-top: 15px;">
    <div class="container">
        <div class="row">
            <div class="features">
                <div data-aos="fade-left" class="equal-height col-md-3 col-sm-6" style="height: 320px;">
                    <div class="item mariner">
                        <a href="#">
                            <div style="height: 220px;" class="info">

                                <p>
                                    <img src="<?php echo e(getImage('teachers', $item->user->userDetails->image)); ?>" height="180" width="200" alt="<?php echo e($item->title); ?>">
                                </p>
                                <p class="text-center" style="font-weight: bold; font-size: 14px;"> <?php echo e($item->user->name); ?></p>
                                <p class="text-center"><strong>head Of Department</strong></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div data-aos="fade-up" class="equal-height col-md-9 col-sm-6" style="height: 320px;">
                    <div class="item brilliantrose">
                        <a href="<?php echo e(route('front.departments.intro', $item->slug)); ?>">
                            <div style="height: 220px;" class="info">
                                <h4>Introduction to the Department</h4>
                                <?php echo e($item->short); ?>

                                <strong class="text-info">Read More</strong>
                            </div>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<div class="blog-area default-padding bottom-less">
    <div class="container">
       <div class="row">
          <div class="site-heading text-center">
             <div class="col-md-8 col-md-offset-2">
                <h2>Programs of this Department</h2>
             </div>
          </div>
       </div>
       <div class="row">
          <div class="blog-items event-carousel owl-theme owl-carousel">
             <!-- Single Item -->
             <!-- End Single Item -->
            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div data-aos="zoom-in-up" class="equal-height aos-init aos-animate" style="height: 550px;">
                <div class="item">
                    <!--<div class="thumb">-->
                    <!--    <?php if($item->image): ?>-->
                    <!--    <img src="<?php echo e(getImage('programs', $program->image)); ?>" style="height:250px;" alt="<?php echo e($program->title); ?>">-->
                    <!--    <?php else: ?>-->
                    <!--    <img src="<?php echo e(getImage('faculties', $item->image)); ?>" style="height:250px;" alt="<?php echo e($program->title); ?>">-->

                    <!--    <?php endif; ?>-->

                    <!--</div>-->
                    <div class="info">
                        <div class="info-box" style="padding:35px 35px">

                            <div class="content" style="margin-left: 0px; padding: 0">
                                <h4 class="text-left " style="height: 50px; word-spacing: 5px">
                                    <a href="<?php echo e(route('front.programs.show', $program->slug)); ?>"><?php echo e(StrLimit($program->title, 70)); ?></a>
                                </h4>
                                <p style="height: 100px">
                                    <?php echo e(StrLimit($program->short, 150)); ?>

                                </p>
                                <div class="bottom" style="margin-top: 20px">
                                    <div class="col-sm-12">
                                        <a href="<?php echo e(route('front.programs.show', $program->slug)); ?>" class="btn circle btn-dark border btn-sm text-center">
                                            <i style="color: #1C4370" class="fas fa-plus"></i> Read More
                                        </a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <br>
          <div class="more-btn col-md-12 text-center">
            <a href="<?php echo e(route('front.departments')); ?>" class="btn btn-theme effect btn-md">View All Departments</a>
        </div>
       </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.departments.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pstu-main\resources\views/frontend/departments/show.blade.php ENDPATH**/ ?>