<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="block-header">
        <h2>View Faculty</h2>
        <small class="text-muted">Patuakhali Science & Technology University</small>
    </div>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <Strong>Faculty Title: </Strong> <span><?php echo e($item->title); ?></span>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <Strong>Dean of Faculty: </Strong> <span><?php echo e($item->user->name); ?></span>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <Strong>Dean Image: </Strong> <span><img src="<?php echo e(getImage('teachers', $item->user->userDetails->image)); ?>" alt="" width="200"></span>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <Strong>Faculty Image: </Strong> <span><img src="<?php echo e(getImage('faculties', $item->image)); ?>" alt="" width="200"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row clearfix">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <Strong>Faculty Short Intro: </Strong> <span><?php echo e($item->short); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="row clearfix">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <Strong>Faculty Full Intro: </Strong> <br>
                                    <?php echo $item->introduction; ?>

                                </div>
                            </div>
                        </div>

                    </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/backend/academic_calendars/view.blade.php ENDPATH**/ ?>