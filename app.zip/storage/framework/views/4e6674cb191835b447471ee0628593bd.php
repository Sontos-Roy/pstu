<?php $__env->startSection('content'); ?>
    <div class="breadcrumb-area shadow dark text-center text-light" style="background-image: url('<?php echo e(getImage('settings', getSetting('pagebanner1'))); ?>'); background-repeat: no-repeat; padding: 103px 0;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h2>All Libraires</h2>
                    <ul class="breadcrumb">
                        <li><a href="<?php echo e(route('front.home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                        <li class="active">All Libraires</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="course-details-area default-padding">
        <div class="container">
            <div class="row">
                <!-- Start Course Info -->
                <div class="col-md-12">
                    <div class="event-items">
                       <?php $__empty_1 = true; $__currentLoopData = $libraries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                       <div class="item col-sm-11" style="margin-bottom:30px">
                        <div style="border: 1px solid #eee;padding: 15px">
                           <div class="col-md-5 thumb">
                              <img src="<?php echo e(getImage('libraries', $item->image)); ?>">
                           </div>
                           <div class="col-md-7 info">
                              <div class="info-box">
                                 <div class="content">
                                    <h3> <a href="<?php echo e($item->website); ?>">Science Library</a></h3>
                                    <p class="text-justify">
                                       <?php echo e($item->short); ?>

                                    </p>
                                    <div class="bottom">
                                        <a href="<?php echo e($item->website); ?>" target="_blank" class="btn circle btn-dark border btn-sm text-center">
                                        <i class="fas fa-chart-bar"></i> Website
                                        </a>
                                     </div>
                                 </div>
                              </div>
                           </div>
                           <div class="clearfix"></div>
                        </div>
                     </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <center>
                            <h2>Empty</h2>
                        </center>
                       <?php endif; ?>
                    </div>
                 </div>
            </div>
        </div>
    </div>





    <!-- Start Footer


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\pstulive\resources\views/frontend/libraries.blade.php ENDPATH**/ ?>